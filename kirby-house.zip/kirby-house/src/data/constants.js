export const RW = 18      // room width
export const RD = 14      // room depth
export const WH = 7       // wall height
export const EST_D = 4    // estrade depth
export const EST_H = 0.28 // estrade height
export const CELL = 1.0   // grid cell size

// Camera
export const CAM_H = Math.PI * 0.25
export const CAM_V = 0.52
