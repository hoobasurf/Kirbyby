import { useRef } from 'react'
import Scene from './components/Scene'
import UI, { Joystick } from './components/UI'

export default function App() {
  const joystickAxis = useRef({ x: 0, y: 0 })

  return (
    <div style={{ position: 'fixed', inset: 0, overflow: 'hidden', background: '#0a0605' }}>
      {/* 3D Canvas */}
      <Scene joystickAxis={joystickAxis} />

      {/* 2D UI overlay */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'auto' }}>
          <UI />
          <Joystick axisRef={joystickAxis} />
          <button
            style={{
              position: 'absolute', right: 10, bottom: 10, zIndex: 40,
              width: 52, height: 52, borderRadius: '50%',
              background: 'radial-gradient(circle at 35% 35%,#ffe888,#c8a020)',
              border: '2.5px solid rgba(255,255,255,.8)', fontSize: 22, cursor: 'pointer',
              boxShadow: '0 3px 12px rgba(0,0,0,.5)',
            }}
            onTouchStart={(e) => { e.preventDefault(); window.__kirbyJump?.() }}
            onClick={() => window.__kirbyJump?.()}
          >✨</button>
        </div>
      </div>
    </div>
  )
}
