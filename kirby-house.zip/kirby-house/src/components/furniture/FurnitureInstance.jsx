import { useCallback } from 'react'
import { ThreeEvent } from '@react-three/fiber'
import { CATALOG } from '../../store/useStore'
import { FURNITURE_MAP } from './Furniture'
import { CELL } from '../../data/constants'
import useStore from '../../store/useStore'

export default function FurnitureInstance({ item }) {
  const def = CATALOG.find((c) => c.id === item.id)
  const Component = FURNITURE_MAP[item.id]
  const selectItem = useStore((s) => s.selectItem)
  const mode = useStore((s) => s.mode)

  if (!def || !Component) return null

  const x = item.gx + (def.W * CELL) / 2
  const z = item.gz + (def.D * CELL) / 2
  const rotY = ((item.rot || 0) * Math.PI) / 8

  const handleClick = (e) => {
    e.stopPropagation()
    if (mode === 'play') selectItem(item.uid)
  }

  return (
    <group
      position={[x, 0, z]}
      rotation={[0, rotY, 0]}
      onClick={handleClick}
      userData={{ itemUID: item.uid }}
    >
      <Component />
    </group>
  )
}
