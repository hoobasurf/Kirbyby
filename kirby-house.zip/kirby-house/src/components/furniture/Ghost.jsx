import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { CATALOG } from '../../store/useStore'
import { FURNITURE_MAP } from './Furniture'
import { CELL } from '../../data/constants'

// Wraps a furniture component with ghost material
function GhostWrapper({ children }) {
  const groupRef = useRef()

  useFrame(({ clock }) => {
    if (!groupRef.current) return
    const pulse = 0.55 + Math.sin(clock.getElapsedTime() * 3) * 0.1
    groupRef.current.traverse((child) => {
      if (child.isMesh && child.material) {
        child.material.opacity = pulse
      }
    })
  })

  return (
    <group ref={groupRef}>
      {children}
    </group>
  )
}

export default function Ghost({ def, position }) {
  const Component = def ? FURNITURE_MAP[def.id] : null
  if (!Component || !def) return null

  const px = CATALOG.find((c) => c.id === def.id)
  const x = position[0] + (def.W * CELL) / 2
  const z = position[2] + (def.D * CELL) / 2

  return (
    <group position={[x, 0.02, z]}>
      {/* Grid cell highlight */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <planeGeometry args={[def.W * CELL - 0.05, def.D * CELL - 0.05]} />
        <meshBasicMaterial color="#d4a017" transparent opacity={0.25} depthWrite={false} />
      </mesh>
      {/* Ghost object */}
      <GhostWrapper>
        <Component />
      </GhostWrapper>
    </group>
  )
}
