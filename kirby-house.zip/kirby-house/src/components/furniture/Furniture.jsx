import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { WH } from '../../data/constants'

// ── Material helpers ─────────────────────────────────
const wood    = { color: '#4a2010', roughness: 0.85, metalness: 0.0 }
const woodL   = { color: '#7a4020', roughness: 0.85, metalness: 0.0 }
const gold    = { color: '#d4a017', roughness: 0.25, metalness: 0.75 }
const fabric  = { color: '#cc6633', roughness: 0.95, metalness: 0.0 }
const fabricD = { color: '#aa4422', roughness: 0.95, metalness: 0.0 }
const white   = { color: '#f5f0e8', roughness: 0.85, metalness: 0.0 }
const whiteS  = { color: '#eef6ff', roughness: 0.8,  metalness: 0.0 }
const chrome  = { color: '#c0c8d0', roughness: 0.15, metalness: 0.9 }
const glass   = { color: '#88ccdd', roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.55 }
const marble  = { color: '#f0ece4', roughness: 0.4,  metalness: 0.05 }
const ebony   = { color: '#0a0808', roughness: 0.6,  metalness: 0.05 }
const greenLeaf = { color: '#2a8a30', roughness: 0.9, metalness: 0.0 }
const water   = { color: '#44aacc', roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.82 }

function M({ args, mat, pos, rot, cast, receive, children, ...rest }) {
  return (
    <mesh
      position={pos}
      rotation={rot}
      castShadow={cast}
      receiveShadow={receive}
      {...rest}
    >
      {args}
      <meshStandardMaterial {...mat} />
      {children}
    </mesh>
  )
}

// ── BED ─────────────────────────────────────────────
export function Bed() {
  return (
    <group>
      <M args={<boxGeometry args={[1.95, 0.26, 1.98]} />} mat={wood} pos={[0, 0.13, 0]} cast />
      <M args={<boxGeometry args={[1.82, 0.2, 1.85]} />} mat={{ color: '#f0e8d8', roughness: 0.9 }} pos={[0, 0.33, 0]} cast />
      <M args={<boxGeometry args={[1.78, 0.11, 1.5]} />} mat={{ color: '#8b1a1a', roughness: 0.9 }} pos={[0, 0.44, -0.18]} />
      {[-0.48, 0.48].map((x, i) => (
        <M key={i} args={<boxGeometry args={[0.75, 0.13, 0.38]} />} mat={white} pos={[x, 0.48, 0.72]} />
      ))}
      {/* Headboard */}
      <M args={<boxGeometry args={[0.18, 1.05, 1.96]} />} mat={wood} pos={[-0.9, 0.6, 0]} cast />
      <M args={<boxGeometry args={[0.05, 0.78, 1.6]} />} mat={gold} pos={[-0.82, 0.6, 0]} />
      {/* Nightstands */}
      {[-1.1, 1.1].map((sx, i) => (
        <group key={i}>
          <M args={<boxGeometry args={[0.48, 0.4, 0.46]} />} mat={wood} pos={[sx * 0.5 * 2, 0.2, 0.18]} cast />
          <M args={<cylinderGeometry args={[0.035, 0.035, 0.22, 10]} />} mat={gold} pos={[sx * 0.5 * 2, 0.56, 0.18]} />
          <M args={<cylinderGeometry args={[0.18, 0.07, 0.2, 14]} />} mat={{ color: '#fff4d0', roughness: 0.7 }} pos={[sx * 0.5 * 2, 0.7, 0.18]} />
          <pointLight position={[sx * 0.5 * 2, 0.65, 0.18]} intensity={8} distance={4} color="#ffcc66" />
        </group>
      ))}
    </group>
  )
}

// ── SOFA ─────────────────────────────────────────────
export function Sofa() {
  return (
    <group>
      <M args={<boxGeometry args={[1.95, 0.16, 0.94]} />} mat={wood} pos={[0, 0.08, 0]} cast />
      {[-0.55, 0.55].map((x, i) => (
        <M key={i} args={<boxGeometry args={[0.88, 0.22, 0.8]} />} mat={fabric} pos={[x, 0.28, 0.02]} cast />
      ))}
      <M args={<boxGeometry args={[1.96, 0.58, 0.18]} />} mat={fabricD} pos={[0, 0.54, -0.37]} cast />
      {[-0.55, 0.55].map((x, i) => (
        <M key={i} args={<boxGeometry args={[0.88, 0.48, 0.17]} />} mat={fabric} pos={[x, 0.52, -0.36]} />
      ))}
      {[-1.02, 1.02].map((sx, i) => (
        <group key={i}>
          <M args={<boxGeometry args={[0.18, 0.44, 0.94]} />} mat={fabricD} pos={[sx, 0.34, 0]} cast />
          <M args={<boxGeometry args={[0.22, 0.055, 0.98]} />} mat={wood} pos={[sx, 0.58, 0]} />
        </group>
      ))}
    </group>
  )
}

// ── ARMCHAIR ─────────────────────────────────────────
export function Armchair() {
  return (
    <group>
      <M args={<boxGeometry args={[0.78, 0.15, 0.74]} />} mat={wood} pos={[0, 0.075, 0]} cast />
      <M args={<boxGeometry args={[0.74, 0.22, 0.68]} />} mat={fabric} pos={[0, 0.26, 0.02]} cast />
      <M args={<boxGeometry args={[0.76, 0.58, 0.17]} />} mat={fabricD} pos={[0, 0.6, -0.29]} cast />
      {[-0.4, 0.4].map((sx, i) => (
        <M key={i} args={<boxGeometry args={[0.17, 0.34, 0.7]} />} mat={fabricD} pos={[sx, 0.32, 0]} />
      ))}
    </group>
  )
}

// ── COFFEE TABLE ──────────────────────────────────────
export function CoffeeTable() {
  return (
    <group>
      <M args={<cylinderGeometry args={[0.5, 0.5, 0.07, 8]} />} mat={woodL} pos={[0, 0.5, 0]} cast />
      <M args={<cylinderGeometry args={[0.42, 0.42, 0.035, 8]} />} mat={glass} pos={[0, 0.55, 0]} />
      {[0, 1, 2, 3].map((i) => {
        const a = (i / 4) * Math.PI * 2 + Math.PI / 4
        return (
          <M key={i} args={<boxGeometry args={[0.07, 0.5, 0.07]} />} mat={wood} pos={[Math.cos(a) * 0.36, 0.25, Math.sin(a) * 0.36]} />
        )
      })}
    </group>
  )
}

// ── DINING TABLE ──────────────────────────────────────
export function DiningTable() {
  return (
    <group>
      <M args={<boxGeometry args={[1.88, 0.09, 1.88]} />} mat={woodL} pos={[0, 0.76, 0]} cast />
      {[[0.78, 0.34, 0.78], [0.78, 0.34, -0.78], [-0.78, 0.34, 0.78], [-0.78, 0.34, -0.78]].map(([x, y, z], i) => (
        <M key={i} args={<cylinderGeometry args={[0.05, 0.06, 0.68, 8]} />} mat={wood} pos={[x, y, z]} cast />
      ))}
      {[[0, 0.88], [0, -0.88], [-0.88, 0], [0.88, 0]].map(([px, pz], i) => (
        <group key={i} position={[px, 0, pz]} rotation={[0, i >= 2 ? Math.PI / 2 : 0, 0]}>
          <M args={<boxGeometry args={[0.54, 0.07, 0.5]} />} mat={fabric} pos={[0, 0.48, 0]} />
          <M args={<boxGeometry args={[0.54, 0.48, 0.09]} />} mat={fabricD} pos={[0, 0.76, -0.21]} cast />
        </group>
      ))}
    </group>
  )
}

// ── DESK ─────────────────────────────────────────────
export function Desk() {
  return (
    <group>
      <M args={<boxGeometry args={[1.86, 0.09, 0.8]} />} mat={woodL} pos={[0, 0.64, 0]} cast />
      {[[0.84, 0.3, 0.34], [-0.84, 0.3, 0.34], [0.84, 0.3, -0.34], [-0.84, 0.3, -0.34]].map(([x, y, z], i) => (
        <M key={i} args={<cylinderGeometry args={[0.035, 0.045, 0.6, 8]} />} mat={wood} pos={[x, y, z]} cast />
      ))}
      {/* Lamp */}
      <M args={<cylinderGeometry args={[0.028, 0.028, 0.22, 8]} />} mat={gold} pos={[-0.48, 0.76, 0.09]} />
      <M args={<cylinderGeometry args={[0.14, 0.055, 0.18, 14]} />} mat={{ color: '#fff4d0', roughness: 0.7 }} pos={[-0.48, 0.94, 0.09]} />
      <pointLight position={[-0.48, 0.88, 0.09]} intensity={6} distance={3} color="#ffcc66" />
    </group>
  )
}

// ── WARDROBE ─────────────────────────────────────────
export function Wardrobe() {
  return (
    <group>
      <M args={<boxGeometry args={[0.84, 1.74, 0.58]} />} mat={wood} pos={[0, 0.87, 0]} cast />
      <M args={<boxGeometry args={[0.88, 0.09, 0.62]} />} mat={gold} pos={[0, 1.96, 0]} />
      {[-1, 1].map((sx, i) => (
        <group key={i}>
          <M args={<boxGeometry args={[0.38, 1.62, 0.055]} />} mat={woodL} pos={[sx * 0.2, 0.86, 0.31]} />
          <M args={<cylinderGeometry args={[0.022, 0.022, 0.16, 6]} />} mat={gold} pos={[sx * 0.2, 0.72, 0.34]} rotation={[0, 0, Math.PI / 2]} />
        </group>
      ))}
    </group>
  )
}

// ── BOOKSHELF ────────────────────────────────────────
const BOOK_COLORS = ['#8b2222', '#1a3a7a', '#2a7a2a', '#aa8822', '#6a2a8a', '#2a7a8a', '#aa4422', '#226688']

export function Bookshelf() {
  return (
    <group>
      <M args={<boxGeometry args={[0.86, 1.74, 0.46]} />} mat={wood} pos={[0, 0.87, 0]} cast />
      <M args={<boxGeometry args={[0.88, 0.09, 0.48]} />} mat={gold} pos={[0, 1.96, 0]} />
      {[0.26, 0.62, 1.0, 1.38].map((y, ri) => {
        const nb = 4 + ri
        const bw = 0.78 / nb
        return (
          <group key={ri}>
            <M args={<boxGeometry args={[0.82, 0.055, 0.42]} />} mat={woodL} pos={[0, y, 0]} />
            {Array.from({ length: nb }).map((_, bi) => (
              <M
                key={bi}
                args={<boxGeometry args={[bw - 0.02, 0.18 + (bi % 3) * 0.06, 0.38]} />}
                mat={{ color: BOOK_COLORS[(ri * 4 + bi) % BOOK_COLORS.length], roughness: 0.9 }}
                pos={[-0.37 + bi * bw + bw / 2, y + 0.13, 0]}
              />
            ))}
          </group>
        )
      })}
    </group>
  )
}

// ── TV ───────────────────────────────────────────────
export function TV() {
  return (
    <group>
      <M args={<boxGeometry args={[1.94, 0.4, 0.52]} />} mat={wood} pos={[0, 0.2, 0]} cast />
      <M args={<boxGeometry args={[1.96, 0.048, 0.54]} />} mat={gold} pos={[0, 0.42, 0]} />
      <M args={<boxGeometry args={[1.8, 1.06, 0.075]} />} mat={ebony} pos={[0, 1.14, 0]} cast />
      <M
        args={<boxGeometry args={[1.66, 0.9, 0.035]} />}
        mat={{ color: '#080c1e', roughness: 0.1, metalness: 0.2, emissive: '#101840', emissiveIntensity: 1.4 }}
        pos={[0, 1.14, 0.065]}
      />
    </group>
  )
}

// ── PIANO ────────────────────────────────────────────
export function Piano() {
  return (
    <group>
      <M args={<boxGeometry args={[1.78, 0.7, 1.02]} />} mat={ebony} pos={[0, 0.43, 0]} cast />
      <M args={<boxGeometry args={[1.76, 0.048, 0.94]} />} mat={{ color: '#141010', roughness: 0.5 }} pos={[0, 0.76, -0.04]} rotation={[-0.26, 0, 0]} />
      <M args={<boxGeometry args={[1.36, 0.055, 0.22]} />} mat={white} pos={[0, 0.7, 0.44]} />
      {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
        <M key={i} args={<boxGeometry args={[0.055, 0.085, 0.13]} />} mat={ebony} pos={[-0.5 + i * 0.15, 0.72, 0.4]} />
      ))}
      {[[-0.7, -0.4], [0.7, -0.4], [0, 0.44]].map(([x, z], i) => (
        <M key={i} args={<cylinderGeometry args={[0.05, 0.065, 0.48, 8]} />} mat={wood} pos={[x, 0.24, z]} cast />
      ))}
    </group>
  )
}

// ── BAR ──────────────────────────────────────────────
export function Bar() {
  const bottleColors = ['#224488', '#882222', '#228822', '#884400', '#663388']
  return (
    <group>
      <M args={<boxGeometry args={[1.88, 0.94, 0.52]} />} mat={wood} pos={[0, 0.47, 0]} cast />
      <M args={<boxGeometry args={[1.94, 0.09, 0.6]} />} mat={gold} pos={[0, 0.94, 0.04]} />
      {bottleColors.map((c, i) => (
        <M key={i} args={<cylinderGeometry args={[0.05, 0.037, 0.26, 10]} />}
          mat={{ color: c, roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.85 }}
          pos={[-0.7 + i * 0.34, 0.84, -0.075]} cast />
      ))}
      <M args={<boxGeometry args={[0.055, 0.96, 1.84]} />} mat={glass} pos={[-0.94, 0.48, 0]} />
    </group>
  )
}

// ── RUG ──────────────────────────────────────────────
export function Rug() {
  return (
    <group>
      <M args={<boxGeometry args={[1.9, 0.055, 1.9]} />} mat={{ color: '#8b3a22', roughness: 0.98 }} pos={[0, 0.028, 0]} />
      <M args={<boxGeometry args={[1.58, 0.038, 1.58]} />} mat={{ color: '#aa4a32', roughness: 0.98 }} pos={[0, 0.046, 0]} />
      <M args={<boxGeometry args={[0.88, 0.038, 0.88]} />} mat={{ color: '#d4a017', roughness: 0.95 }} pos={[0, 0.058, 0]} />
    </group>
  )
}

// ── FLOOR LAMP ───────────────────────────────────────
export function FloorLamp() {
  return (
    <group>
      <M args={<cylinderGeometry args={[0.2, 0.26, 0.075, 16]} />} mat={woodL} pos={[0, 0.038, 0]} />
      <M args={<cylinderGeometry args={[0.035, 0.035, 0.54, 8]} />} mat={gold} pos={[0, 0.35, 0]} />
      <M args={<sphereGeometry args={[0.082, 12, 10]} />} mat={gold} pos={[0, 0.64, 0]} />
      <M args={<cylinderGeometry args={[0.028, 0.035, 0.46, 8]} />} mat={gold} pos={[0, 0.94, 0]} />
      <M args={<cylinderGeometry args={[0.3, 0.11, 0.28, 16]} />} mat={{ color: '#fff4d0', roughness: 0.7 }} pos={[0, 1.3, 0]} />
      <M args={<sphereGeometry args={[0.055, 10, 8]} />} mat={{ color: '#fffff0', roughness: 0.2, emissive: '#ffdd88', emissiveIntensity: 5 }} pos={[0, 1.22, 0]} />
      <pointLight position={[0, 1.15, 0]} intensity={20} distance={8} color="#ffcc66" />
    </group>
  )
}

// ── TABLE LAMP ───────────────────────────────────────
export function TableLamp() {
  return (
    <group>
      <M args={<cylinderGeometry args={[0.09, 0.13, 0.075, 14]} />} mat={gold} pos={[0, 0.038, 0]} />
      <M args={<sphereGeometry args={[0.092, 12, 10]} />} mat={gold} pos={[0, 0.17, 0]} />
      <M args={<cylinderGeometry args={[0.022, 0.028, 0.16, 8]} />} mat={gold} pos={[0, 0.3, 0]} />
      <M args={<cylinderGeometry args={[0.2, 0.08, 0.2, 16]} />} mat={{ color: '#fff4d0', roughness: 0.7 }} pos={[0, 0.44, 0]} />
      <M args={<sphereGeometry args={[0.04, 8, 6]} />} mat={{ color: '#fffff0', roughness: 0.2, emissive: '#ffdd88', emissiveIntensity: 4 }} pos={[0, 0.4, 0]} />
      <pointLight position={[0, 0.38, 0]} intensity={12} distance={5} color="#ffcc66" />
    </group>
  )
}

// ── CHANDELIER ───────────────────────────────────────
export function Chandelier() {
  const flameRefs = useRef([])
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    flameRefs.current.forEach((ref, i) => {
      if (!ref) return
      ref.scale.y = 0.8 + Math.sin(t * 5 + i * 0.5) * 0.26
      ref.scale.x = 0.8 + Math.cos(t * 4 + i * 0.5) * 0.2
    })
  })

  return (
    <group>
      <M args={<cylinderGeometry args={[0.028, 0.028, 0.5, 6]} />} mat={gold} pos={[0, WH - 1.7, 0]} />
      <mesh position={[0, WH - 2.24, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.58, 0.065, 8, 24]} />
        <meshStandardMaterial {...gold} />
      </mesh>
      {Array.from({ length: 6 }).map((_, i) => {
        const a = (i / 6) * Math.PI * 2
        const cx = Math.cos(a) * 0.66, cz = Math.sin(a) * 0.66
        return (
          <group key={i}>
            <M args={<cylinderGeometry args={[0.036, 0.036, 0.16, 8]} />} mat={{ color: '#fff0d0', roughness: 0.9 }} pos={[cx, WH - 2.18, cz]} />
            <mesh ref={(el) => (flameRefs.current[i] = el)} position={[cx, WH - 2.04, cz]}>
              <coneGeometry args={[0.036, 0.09, 6]} />
              <meshStandardMaterial color="#ff9900" emissive="#ff6600" emissiveIntensity={4} transparent opacity={0.9} />
            </mesh>
            <pointLight position={[cx, WH - 2.1, cz]} intensity={4} distance={3.5} color="#ffcc66" />
          </group>
        )
      })}
      <mesh position={[0, WH - 2.65, 0]}>
        <octahedronGeometry args={[0.13]} />
        <meshStandardMaterial color="#d0f0ff" emissive="#88ccff" emissiveIntensity={0.8} transparent opacity={0.85} />
      </mesh>
    </group>
  )
}

// ── FIREPLACE ────────────────────────────────────────
export function Fireplace() {
  const flameRefs = useRef([])
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    flameRefs.current.forEach((ref, i) => {
      if (!ref) return
      ref.scale.y = 0.8 + Math.sin(t * 5 + i * 0.34) * 0.3
      ref.scale.x = 0.8 + Math.cos(t * 4 + i * 0.34) * 0.22
    })
  })
  const flameColors = ['#ff2200', '#ff5500', '#ff8800', '#ffaa00', '#ffcc44']

  return (
    <group>
      <M args={<boxGeometry args={[1.96, 1.32, 0.54]} />} mat={wood} pos={[0, 0.66, 0]} cast />
      {[-1, 1].map((sx, i) => (
        <M key={i} args={<boxGeometry args={[0.2, 0.96, 0.54]} />} mat={gold} pos={[sx * 0.85, 0.5, 0]} cast />
      ))}
      <M args={<boxGeometry args={[2.12, 0.13, 0.72]} />} mat={marble} pos={[0, 1.32, 0.11]} cast />
      <M args={<boxGeometry args={[1.24, 0.9, 0.54]} />} mat={{ color: '#0a0604', roughness: 0.95 }} pos={[0, 0.48, 0.01]} />
      {Array.from({ length: 7 }).map((_, i) => {
        const fh = 0.22 + i * 0.055
        return (
          <mesh key={i} ref={(el) => (flameRefs.current[i] = el)} position={[-0.26 + i * 0.095, 0.09 + fh / 2, -0.02]}>
            <coneGeometry args={[0.065 + i * 0.024, fh, 8]} />
            <meshStandardMaterial
              color={flameColors[i % 5]}
              emissive={flameColors[i % 5]}
              emissiveIntensity={3}
              transparent
              opacity={0.9}
            />
          </mesh>
        )
      })}
      <pointLight position={[0, 0.78, 0.65]} intensity={25} distance={6.5} color="#ff6600" />
    </group>
  )
}

// ── CANDLES ──────────────────────────────────────────
export function Candles() {
  const flameRefs = useRef([])
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    flameRefs.current.forEach((ref, i) => {
      if (!ref) return
      ref.scale.y = 0.8 + Math.sin(t * 6 + i) * 0.3
    })
  })
  const candles = [[0, 0, 0.13, 0.3], [0.22, -0.09, 0.095, 0.2], [-0.2, 0.11, 0.1, 0.24]]
  return (
    <group>
      <M args={<cylinderGeometry args={[0.36, 0.38, 0.036, 16]} />} mat={gold} pos={[0, 0.018, 0]} />
      {candles.map(([x, z, r, h], i) => (
        <group key={i}>
          <M args={<cylinderGeometry args={[r, r, h, 10]} />} mat={{ color: '#fff0d8', roughness: 0.9 }} pos={[x, h / 2 + 0.036, z]} />
          <mesh ref={(el) => (flameRefs.current[i] = el)} position={[x, h + 0.082, z]}>
            <coneGeometry args={[0.034, 0.082, 8]} />
            <meshStandardMaterial color="#ff9900" emissive="#ff6600" emissiveIntensity={4} transparent opacity={0.9} />
          </mesh>
          <pointLight position={[x, h + 0.06, z]} intensity={3} distance={2} color="#ffcc66" />
        </group>
      ))}
    </group>
  )
}

// ── PLANT ────────────────────────────────────────────
export function Plant() {
  return (
    <group>
      <M args={<cylinderGeometry args={[0.22, 0.26, 0.36, 16]} />} mat={marble} pos={[0, 0.18, 0]} cast />
      <M args={<cylinderGeometry args={[0.2, 0.21, 0.055, 16]} />} mat={{ color: '#3a1a08', roughness: 0.95 }} pos={[0, 0.38, 0]} />
      <M args={<cylinderGeometry args={[0.036, 0.046, 0.52, 8]} />} mat={{ color: '#5a3818', roughness: 0.9 }} pos={[0, 0.67, 0]} />
      {Array.from({ length: 8 }).map((_, i) => {
        const a = (i / 8) * Math.PI * 2
        return (
          <M
            key={i}
            args={<boxGeometry args={[0.075, 0.52, 0.2]} />}
            mat={{ color: ['#2a8a30', '#3aaa40', '#44bb44', '#228822'][i % 4], roughness: 0.9 }}
            pos={[Math.cos(a) * 0.2, 0.7 + Math.sin(i * 0.8) * 0.055, Math.sin(a) * 0.2]}
            rotation={[0, a, Math.PI / 2 - 0.44]}
          />
        )
      })}
    </group>
  )
}

// ── PAINTING ─────────────────────────────────────────
export function Painting() {
  return (
    <group>
      <M args={<boxGeometry args={[0.075, 0.74, 0.62]} />} mat={gold} pos={[0.065, 0.6, 0]} />
      <M args={<boxGeometry args={[0.046, 0.64, 0.53]} />} mat={{ color: '#d4b888', roughness: 0.85 }} pos={[0.096, 0.6, 0]} />
      <M args={<boxGeometry args={[0.018, 0.28, 0.24]} />} mat={{ color: '#8b3a1a', roughness: 0.9 }} pos={[0.112, 0.68, 0.048]} />
      <M args={<boxGeometry args={[0.018, 0.18, 0.18]} />} mat={{ color: '#4a5a9a', roughness: 0.9 }} pos={[0.112, 0.53, -0.096]} />
    </group>
  )
}

// ── MIRROR ───────────────────────────────────────────
export function Mirror() {
  return (
    <group>
      <M args={<boxGeometry args={[0.065, 1.28, 0.86]} />} mat={gold} pos={[0.065, 0.68, 0]} />
      <M args={<boxGeometry args={[0.046, 1.1, 0.72]} />} mat={{ color: '#c8e0e8', roughness: 0.05, metalness: 0.6, transparent: true, opacity: 0.7 }} pos={[0.096, 0.68, 0]} />
      {[[0, 0.6], [0, -0.6], [0.46, 0], [-0.46, 0]].map(([z, y], i) => (
        <mesh key={i} position={[0.065, 0.68 + y, z]}>
          <octahedronGeometry args={[0.065]} />
          <meshStandardMaterial {...gold} />
        </mesh>
      ))}
    </group>
  )
}

// ── CLOCK ────────────────────────────────────────────
export function Clock() {
  const hourRef = useRef()
  const minRef = useRef()
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    if (hourRef.current) hourRef.current.rotation.z = -t * 0.48
    if (minRef.current) minRef.current.rotation.z = -t * 2.4
  })
  return (
    <group>
      <M args={<cylinderGeometry args={[0.16, 0.2, 0.055, 16]} />} mat={woodL} pos={[0, 0.028, 0]} />
      <M args={<cylinderGeometry args={[0.072, 0.09, 0.36, 10]} />} mat={wood} pos={[0, 0.24, 0]} />
      <M args={<cylinderGeometry args={[0.3, 0.3, 0.075, 24]} />} mat={{ color: '#f5eedd', roughness: 0.8 }} pos={[0, 0.48, 0]} rotation={[Math.PI / 2, 0, 0]} />
      <mesh position={[0, 0.48, 0.055]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.28, 0.055, 8, 24]} />
        <meshStandardMaterial {...gold} />
      </mesh>
      <mesh ref={hourRef} position={[0, 0.55, 0.11]}>
        <boxGeometry args={[0.036, 0.148, 0.022]} />
        <meshStandardMaterial color="#2a1208" roughness={0.8} />
      </mesh>
      <mesh ref={minRef} position={[0, 0.59, 0.12]}>
        <boxGeometry args={[0.028, 0.2, 0.022]} />
        <meshStandardMaterial color="#3a1a08" roughness={0.8} />
      </mesh>
    </group>
  )
}

// ── CRYSTAL ──────────────────────────────────────────
export function Crystal() {
  return (
    <group>
      <M args={<cylinderGeometry args={[0.13, 0.17, 0.055, 8]} />} mat={woodL} pos={[0, 0.028, 0]} />
      {[[0, 0.42, 0, 0.22], [0.11, 0.33, 0.09, 0.16], [-0.1, 0.3, -0.075, 0.14]].map(([x, y, z, s], i) => (
        <mesh key={i} position={[x, y, z]}>
          <octahedronGeometry args={[s]} />
          <meshStandardMaterial color="#88e8ff" roughness={0.05} metalness={0.1} transparent opacity={0.9} emissive="#44aaff" emissiveIntensity={0.4} />
        </mesh>
      ))}
      <pointLight position={[0, 0.48, 0]} intensity={5} distance={3} color="#88ccff" />
    </group>
  )
}

// ── GLOBE ────────────────────────────────────────────
export function Globe() {
  return (
    <group>
      <M args={<cylinderGeometry args={[0.13, 0.17, 0.055, 14]} />} mat={woodL} pos={[0, 0.028, 0]} />
      <M args={<cylinderGeometry args={[0.036, 0.046, 0.16, 8]} />} mat={{ color: '#8b5c1e', roughness: 0.8 }} pos={[0, 0.14, 0]} />
      <mesh position={[0, 0.36, 0]} rotation={[0, 0, 0.34]}>
        <torusGeometry args={[0.26, 0.036, 8, 24]} />
        <meshStandardMaterial {...gold} />
      </mesh>
      <mesh position={[0, 0.36, 0]}>
        <sphereGeometry args={[0.24, 16, 12]} />
        <meshStandardMaterial color="#2244aa" roughness={0.6} metalness={0.1} />
      </mesh>
    </group>
  )
}

// ── AQUARIUM ─────────────────────────────────────────
export function Aquarium() {
  const fishRefs = useRef([])
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    fishRefs.current.forEach((ref, i) => {
      if (!ref) return
      ref.position.z = Math.sin(t * 1.5 + i * 1.1) * 0.11
      ref.position.y = 0.48 + Math.sin(t * 2 + i) * 0.06
    })
  })
  const fishColors = ['#ff6622', '#2266ff', '#ddcc22', '#ff44aa', '#22ccaa']

  return (
    <group>
      <M args={<boxGeometry args={[1.84, 0.36, 0.56]} />} mat={wood} pos={[0, 0.18, 0]} cast />
      <M args={<boxGeometry args={[1.74, 0.055, 0.5]} />} mat={{ color: '#d4b878', roughness: 0.9 }} pos={[0, 0.092, 0]} />
      <M args={<boxGeometry args={[1.88, 1.0, 0.62]} />} mat={{ ...gold, transparent: true, opacity: 0.4 }} pos={[0, 0.5 + 0.36, 0]} />
      <M args={<boxGeometry args={[1.84, 0.96, 0.58]} />} mat={{ ...glass, opacity: 0.4 }} pos={[0, 0.5 + 0.36, 0]} />
      {fishColors.map((c, i) => (
        <mesh key={i} ref={(el) => (fishRefs.current[i] = el)} position={[-0.48 + i * 0.24, 0.48 + 0.36, 0]}>
          <boxGeometry args={[0.1, 0.06, 0.04]} />
          <meshStandardMaterial color={c} roughness={0.3} metalness={0.2} />
        </mesh>
      ))}
      <pointLight position={[0, 0.88 + 0.36, 0]} intensity={6} distance={2.5} color="#88ddff" />
    </group>
  )
}

// ── BIRDCAGE ─────────────────────────────────────────
export function Birdcage() {
  return (
    <group>
      <M args={<cylinderGeometry args={[0.26, 0.18, 0.055, 16]} />} mat={gold} pos={[0, 0.028, 0]} />
      <M args={<cylinderGeometry args={[0.036, 0.036, 0.78, 8]} />} mat={gold} pos={[0, 0.39, 0]} />
      {Array.from({ length: 12 }).map((_, i) => {
        const a = (i / 12) * Math.PI * 2
        return (
          <M key={i} args={<cylinderGeometry args={[0.012, 0.012, 0.26, 6]} />} mat={gold} pos={[Math.cos(a) * 0.28, 0.94, Math.sin(a) * 0.28]} />
        )
      })}
      {[0.8, 1.07].map((y, i) => (
        <mesh key={i} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.28, 0.028, 8, 24]} />
          <meshStandardMaterial {...gold} />
        </mesh>
      ))}
      <mesh position={[0, 1.07, 0]} rotation={[Math.PI, 0, 0]}>
        <sphereGeometry args={[0.28, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial {...gold} transparent opacity={0.55} />
      </mesh>
      <mesh position={[0.075, 0.95, 0]}>
        <sphereGeometry args={[0.075, 10, 8]} />
        <meshStandardMaterial color="#44aacc" roughness={0.4} />
      </mesh>
    </group>
  )
}

// ── BATHTUB ──────────────────────────────────────────
export function Bathtub() {
  return (
    <group>
      <mesh position={[0, 0.29, 0]} scale={[1.7, 1, 1]} castShadow>
        <cylinderGeometry args={[0.52, 0.56, 0.58, 16]} />
        <meshStandardMaterial {...marble} />
      </mesh>
      <mesh position={[0, 0.32, 0]} scale={[1.65, 1, 1]}>
        <cylinderGeometry args={[0.44, 0.46, 0.5, 16]} />
        <meshStandardMaterial {...whiteS} />
      </mesh>
      <mesh position={[0, 0.53, 0]} rotation={[-Math.PI / 2, 0, 0]} scale={[1.65, 1, 1]}>
        <circleGeometry args={[0.43, 16]} />
        <meshStandardMaterial {...water} />
      </mesh>
      <M args={<boxGeometry args={[0.036, 0.2, 0.055]} />} mat={gold} pos={[-0.82, 0.6, -0.18]} />
    </group>
  )
}

// ── JACUZZI ──────────────────────────────────────────
export function Jacuzzi() {
  const bubbleRefs = useRef([])
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    bubbleRefs.current.forEach((ref, i) => {
      if (!ref) return
      ref.position.y = 0.56 + Math.sin(t * 2.2 + i * 0.34) * 0.09
      if (ref.material) ref.material.opacity = 0.32 + Math.abs(Math.sin(t * 3 + i * 0.34)) * 0.32
    })
  })
  return (
    <group>
      <mesh position={[0, 0.325, 0]} castShadow>
        <cylinderGeometry args={[1.02, 1.07, 0.65, 8]} />
        <meshStandardMaterial {...marble} />
      </mesh>
      <mesh position={[0, 0.31, 0]}>
        <cylinderGeometry args={[0.87, 0.9, 0.58, 8]} />
        <meshStandardMaterial color="#1188cc" roughness={0.3} metalness={0.2} />
      </mesh>
      <mesh position={[0, 0.56, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.85, 16]} />
        <meshStandardMaterial {...water} />
      </mesh>
      {Array.from({ length: 10 }).map((_, i) => {
        const a = (i / 10) * Math.PI * 2
        return (
          <mesh key={i} ref={(el) => (bubbleRefs.current[i] = el)} position={[Math.cos(a) * 0.58, 0.56, Math.sin(a) * 0.58]}>
            <sphereGeometry args={[0.055, 6, 4]} />
            <meshStandardMaterial color="#aaddff" transparent opacity={0.5} />
          </mesh>
        )
      })}
    </group>
  )
}

// ── SHOWER ───────────────────────────────────────────
export function Shower() {
  return (
    <group>
      <M args={<boxGeometry args={[0.9, 0.075, 0.9]} />} mat={{ color: '#d4c8b4', roughness: 0.85 }} pos={[0, 0.038, 0]} />
      {[[0, 0.52, 0.48, 0.036, 1.02, 0.9], [0.48, 0.52, 0, 0.9, 1.02, 0.036], [-0.48, 0.52, 0, 0.9, 1.02, 0.036]].map(
        ([x, y, z, w, h, d], i) => (
          <mesh key={i} position={[x, y, z]}>
            <boxGeometry args={[w, h, d]} />
            <meshStandardMaterial color="#88ccdd" roughness={0.05} transparent opacity={0.38} side={THREE.DoubleSide} />
          </mesh>
        )
      )}
      <M args={<boxGeometry args={[0.036, 0.036, 0.26]} />} mat={chrome} pos={[-0.4, 0.85, 0.13]} />
      <mesh position={[-0.4, 0.85, 0.28]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.092, 0.092, 0.036, 10]} />
        <meshStandardMaterial {...chrome} />
      </mesh>
    </group>
  )
}

// ── WASHBASIN ────────────────────────────────────────
export function Washbasin() {
  return (
    <group>
      <M args={<cylinderGeometry args={[0.11, 0.13, 0.78, 12]} />} mat={marble} pos={[0, 0.39, 0]} cast />
      <mesh position={[0, 0.87, 0]}>
        <cylinderGeometry args={[0.26, 0.18, 0.17, 14]} />
        <meshStandardMaterial {...marble} />
      </mesh>
      <M args={<boxGeometry args={[0.055, 0.148, 0.036]} />} mat={chrome} pos={[0, 1.04, -0.11]} />
    </group>
  )
}

// ── POOL ─────────────────────────────────────────────
export function Pool() {
  return (
    <group>
      <M args={<boxGeometry args={[4.36, 0.148, 2.96]} />} mat={marble} pos={[0, 0.074, 0]} receive />
      {[[0, 0.44, -1.34, 4.36, 0.22, 0.9], [0, 0.44, 1.34, 4.36, 0.22, 0.9], [-2.03, 0.44, 0, 0.22, 0.9, 2.68], [2.03, 0.44, 0, 0.22, 0.9, 2.68]].map(
        ([x, y, z, w, h, d], i) => (
          <M key={i} args={<boxGeometry args={[w, h, d]} />} mat={marble} pos={[x, y, z]} cast />
        )
      )}
      <mesh position={[0, 0.8, 0]}>
        <boxGeometry args={[3.82, 0.075, 2.44]} />
        <meshStandardMaterial {...water} />
      </mesh>
      <M args={<boxGeometry args={[4.4, 0.09, 3.0]} />} mat={gold} pos={[0, 0.86, 0]} />
    </group>
  )
}

// ── FOUNTAIN ─────────────────────────────────────────
export function Fountain() {
  const dropRefs = useRef([])
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    dropRefs.current.forEach((ref, i) => {
      if (!ref) return
      ref.position.y = 0.92 + Math.sin(t * 2.2 + i * 0.38) * 0.09
    })
  })
  return (
    <group>
      <M args={<cylinderGeometry args={[1.07, 1.15, 0.38, 16]} />} mat={marble} pos={[0, 0.19, 0]} cast />
      <mesh position={[0, 0.36, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.92, 16]} />
        <meshStandardMaterial {...water} />
      </mesh>
      <M args={<cylinderGeometry args={[0.11, 0.13, 0.52, 16]} />} mat={gold} pos={[0, 0.65, 0]} />
      <M args={<cylinderGeometry args={[0.5, 0.56, 0.24, 16]} />} mat={marble} pos={[0, 1.06, 0]} cast />
      {Array.from({ length: 8 }).map((_, i) => {
        const a = (i / 8) * Math.PI * 2
        return (
          <mesh key={i} ref={(el) => (dropRefs.current[i] = el)} position={[Math.cos(a) * 0.33, 0.92, Math.sin(a) * 0.33]}>
            <sphereGeometry args={[0.042, 6, 4]} />
            <meshStandardMaterial color="#88ccee" transparent opacity={0.72} />
          </mesh>
        )
      })}
    </group>
  )
}

// ── GAZEBO ───────────────────────────────────────────
export function Gazebo() {
  return (
    <group>
      <mesh position={[0, 0.046, 0]}>
        <cylinderGeometry args={[1.36, 1.36, 0.09, 6]} />
        <meshStandardMaterial color="#d4c4a0" roughness={0.88} />
      </mesh>
      {Array.from({ length: 6 }).map((_, i) => {
        const a = (i / 6) * Math.PI * 2
        return (
          <M key={i} args={<cylinderGeometry args={[0.074, 0.092, 2.14, 10]} />} mat={gold} pos={[Math.cos(a) * 1.24, 1.07, Math.sin(a) * 1.24]} cast />
        )
      })}
      <mesh position={[0, 2.64, 0]}>
        <coneGeometry args={[1.46, 0.96, 6]} />
        <meshStandardMaterial color="#8b5c1e" roughness={0.85} />
      </mesh>
      <mesh position={[0, 3.14, 0]}>
        <sphereGeometry args={[0.11, 8, 6]} />
        <meshStandardMaterial {...gold} />
      </mesh>
    </group>
  )
}

// ── SUNBED ───────────────────────────────────────────
export function Sunbed() {
  return (
    <group>
      <M args={<boxGeometry args={[1.86, 0.11, 0.74]} />} mat={wood} pos={[0, 0.055, 0]} cast />
      <M args={<boxGeometry args={[1.8, 0.092, 0.68]} />} mat={fabric} pos={[0, 0.16, 0]} />
      <mesh position={[0.43, 0.26, -0.01]} rotation={[0, 0, -0.36]} castShadow>
        <boxGeometry args={[0.9, 0.092, 0.7]} />
        <meshStandardMaterial {...fabric} />
      </mesh>
      <M args={<boxGeometry args={[0.36, 0.14, 0.58]} />} mat={{ color: '#fff0d0', roughness: 0.88 }} pos={[-0.6, 0.29, 0]} />
    </group>
  )
}

// ── REGISTRY ─────────────────────────────────────────
export const FURNITURE_MAP = {
  bed: Bed,
  sofa: Sofa,
  armchair: Armchair,
  coffee: CoffeeTable,
  dining: DiningTable,
  desk: Desk,
  wardrobe: Wardrobe,
  bookshelf: Bookshelf,
  tv: TV,
  piano: Piano,
  bar: Bar,
  rug: Rug,
  floorlamp: FloorLamp,
  tablelamp: TableLamp,
  chandelier: Chandelier,
  fireplace: Fireplace,
  candles: Candles,
  plant: Plant,
  painting: Painting,
  mirror: Mirror,
  clock: Clock,
  crystal: Crystal,
  globe: Globe,
  aquarium: Aquarium,
  birdcage: Birdcage,
  bathtub: Bathtub,
  jacuzzi: Jacuzzi,
  shower: Shower,
  washbasin: Washbasin,
  pool: Pool,
  fountain: Fountain,
  gazebo: Gazebo,
  sunbed: Sunbed,
}
