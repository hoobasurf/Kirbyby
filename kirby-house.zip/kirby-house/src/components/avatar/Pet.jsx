import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import useStore from '../../store/useStore'

function CatMesh() {
  const fc = '#ddaa77', fw = '#fff8ee', fp = '#ffaabb', fd = '#bb8855'
  return (
    <group>
      {/* Body */}
      <mesh position={[0, 0.26, 0]} scale={[1.4, 0.88, 1.1]} castShadow>
        <sphereGeometry args={[0.22, 14, 10]} />
        <meshStandardMaterial color={fc} roughness={0.8} />
      </mesh>
      <mesh position={[0, 0.24, 0.18]} scale={[1.1, 0.8, 0.4]}>
        <sphereGeometry args={[0.16, 12, 8]} />
        <meshStandardMaterial color={fw} roughness={0.85} />
      </mesh>
      {/* Head */}
      <mesh position={[0.34, 0.44, 0]} castShadow>
        <sphereGeometry args={[0.18, 14, 12]} />
        <meshStandardMaterial color={fc} roughness={0.8} />
      </mesh>
      {/* Muzzle */}
      <mesh position={[0.52, 0.42, 0]} scale={[1.2, 0.7, 0.6]}>
        <sphereGeometry args={[0.08, 10, 8]} />
        <meshStandardMaterial color={fw} roughness={0.85} />
      </mesh>
      <mesh position={[0.535, 0.445, 0]}>
        <sphereGeometry args={[0.025, 8, 6]} />
        <meshStandardMaterial color="#ee8899" roughness={0.7} />
      </mesh>
      {/* Eyes */}
      {[-1, 1].map((sy, i) => (
        <group key={i}>
          <mesh position={[0.49, 0.48, sy * 0.075]}>
            <sphereGeometry args={[0.038, 10, 8]} />
            <meshStandardMaterial color="#33aa55" roughness={0.2} metalness={0.1} />
          </mesh>
          <mesh position={[0.515, 0.48, sy * 0.075]}>
            <boxGeometry args={[0.008, 0.055, 0.025]} />
            <meshStandardMaterial color="#111111" roughness={0.8} />
          </mesh>
          <mesh position={[0.52, 0.492, sy * 0.075 + 0.016]}>
            <sphereGeometry args={[0.012, 6, 4]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          {/* Ears */}
          <mesh position={[0.32, 0.59, sy * 0.11]}>
            <coneGeometry args={[0.065, 0.12, 8]} />
            <meshStandardMaterial color={fc} roughness={0.8} />
          </mesh>
          <mesh position={[0.32, 0.59, sy * 0.11]}>
            <coneGeometry args={[0.038, 0.08, 8]} />
            <meshStandardMaterial color="#ffaabb" roughness={0.8} />
          </mesh>
          {/* Front paws */}
          <mesh position={[0.28, -0.04, sy * 0.13]} scale={[1.3, 0.55, 0.9]}>
            <sphereGeometry args={[0.065, 10, 8]} />
            <meshStandardMaterial color={fc} roughness={0.8} />
          </mesh>
          {/* Back paws */}
          <mesh position={[-0.2, -0.04, sy * 0.16]} scale={[0.9, 0.52, 1.2]}>
            <sphereGeometry args={[0.08, 10, 8]} />
            <meshStandardMaterial color={fc} roughness={0.8} />
          </mesh>
        </group>
      ))}
      {/* Tail */}
      <mesh position={[-0.34, 0.22, 0]} rotation={[0.3, 0, 0.7]}>
        <cylinderGeometry args={[0.028, 0.022, 0.38, 8]} />
        <meshStandardMaterial color={fd} roughness={0.8} />
      </mesh>
      <mesh position={[-0.52, 0.44, 0]}>
        <sphereGeometry args={[0.042, 8, 6]} />
        <meshStandardMaterial color={fd} roughness={0.8} />
      </mesh>
      {/* Shadow */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.006, 0]}>
        <circleGeometry args={[0.22, 12]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.18} depthWrite={false} />
      </mesh>
    </group>
  )
}

function DogMesh() {
  const fc = '#cc8833', fd = '#aa6622', fw = '#fff0dd'
  return (
    <group>
      <mesh position={[0, 0.28, 0]} scale={[1.5, 0.92, 1.15]} castShadow>
        <sphereGeometry args={[0.24, 14, 10]} />
        <meshStandardMaterial color={fc} roughness={0.8} />
      </mesh>
      <mesh position={[0, 0.25, 0.2]} scale={[1.1, 0.7, 0.38]}>
        <sphereGeometry args={[0.18, 12, 8]} />
        <meshStandardMaterial color={fw} roughness={0.85} />
      </mesh>
      <mesh position={[0.38, 0.46, 0]} castShadow>
        <sphereGeometry args={[0.2, 14, 12]} />
        <meshStandardMaterial color={fc} roughness={0.8} />
      </mesh>
      {/* Muzzle */}
      <mesh position={[0.55, 0.43, 0]} scale={[1.1, 0.78, 0.7]}>
        <sphereGeometry args={[0.11, 10, 8]} />
        <meshStandardMaterial color={fd} roughness={0.8} />
      </mesh>
      <mesh position={[0.595, 0.453, 0]} scale={[1, 0.75, 1]}>
        <sphereGeometry args={[0.038, 10, 8]} />
        <meshStandardMaterial color="#111111" roughness={0.4} metalness={0.1} />
      </mesh>
      {[-1, 1].map((sy, i) => (
        <group key={i}>
          <mesh position={[0.53, 0.5, sy * 0.1]}>
            <sphereGeometry args={[0.036, 10, 8]} />
            <meshStandardMaterial color="#553311" roughness={0.3} />
          </mesh>
          <mesh position={[0.548, 0.5, sy * 0.1]}>
            <sphereGeometry args={[0.022, 8, 6]} />
            <meshStandardMaterial color="#0a0808" roughness={0.5} />
          </mesh>
          <mesh position={[0.555, 0.508, sy * 0.1 + 0.014]}>
            <sphereGeometry args={[0.01, 6, 4]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          {/* Floppy ears */}
          <mesh position={[0.28, 0.44, sy * 0.2]} scale={[0.7, 1.4, 0.45]}>
            <sphereGeometry args={[0.09, 10, 8]} />
            <meshStandardMaterial color={fd} roughness={0.85} />
          </mesh>
          {/* Legs */}
          <mesh position={[0.26, -0.06, sy * 0.14]}>
            <cylinderGeometry args={[0.065, 0.068, 0.2, 10]} />
            <meshStandardMaterial color={fc} roughness={0.8} />
          </mesh>
          <mesh position={[0.26, -0.16, sy * 0.14]} scale={[1.1, 0.52, 1.1]}>
            <sphereGeometry args={[0.075, 10, 8]} />
            <meshStandardMaterial color={fd} roughness={0.8} />
          </mesh>
          <mesh position={[-0.24, -0.06, sy * 0.16]}>
            <cylinderGeometry args={[0.065, 0.068, 0.2, 10]} />
            <meshStandardMaterial color={fc} roughness={0.8} />
          </mesh>
          <mesh position={[-0.24, -0.16, sy * 0.16]} scale={[1.1, 0.52, 1.1]}>
            <sphereGeometry args={[0.075, 10, 8]} />
            <meshStandardMaterial color={fd} roughness={0.8} />
          </mesh>
        </group>
      ))}
      {/* Tail */}
      <mesh position={[-0.36, 0.26, 0]} rotation={[0, 0, 1.1]}>
        <cylinderGeometry args={[0.032, 0.025, 0.32, 8]} />
        <meshStandardMaterial color={fd} roughness={0.8} />
      </mesh>
      {/* Collar */}
      <mesh position={[0.22, 0.34, 0]} rotation={[0.2, 0, 0]}>
        <torusGeometry args={[0.18, 0.025, 8, 18]} />
        <meshStandardMaterial color="#dd2222" roughness={0.7} />
      </mesh>
      <mesh position={[0.22, 0.29, 0.14]} rotation={[Math.PI * 0.4, 0, 0]}>
        <circleGeometry args={[0.028, 8]} />
        <meshStandardMaterial color="#d4a017" roughness={0.3} metalness={0.6} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.006, 0]}>
        <circleGeometry args={[0.24, 12]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.18} depthWrite={false} />
      </mesh>
    </group>
  )
}

function BunnyMesh() {
  const fc = '#fafafa', fd = '#e8e0e0', fp = '#ffaabb'
  return (
    <group>
      <mesh position={[0, 0.3, 0]} scale={[1.2, 1.1, 1.1]} castShadow>
        <sphereGeometry args={[0.22, 14, 10]} />
        <meshStandardMaterial color={fc} roughness={0.85} />
      </mesh>
      <mesh position={[0, 0.28, 0.2]} scale={[0.9, 0.8, 0.38]}>
        <sphereGeometry args={[0.16, 12, 8]} />
        <meshStandardMaterial color={fd} roughness={0.88} />
      </mesh>
      <mesh position={[0.3, 0.5, 0]} castShadow>
        <sphereGeometry args={[0.17, 14, 12]} />
        <meshStandardMaterial color={fc} roughness={0.85} />
      </mesh>
      <mesh position={[0.455, 0.47, 0]} scale={[1.0, 0.7, 0.55]}>
        <sphereGeometry args={[0.075, 10, 8]} />
        <meshStandardMaterial color={fd} roughness={0.88} />
      </mesh>
      <mesh position={[0.485, 0.478, 0]} scale={[1.2, 0.8, 1]}>
        <sphereGeometry args={[0.022, 8, 6]} />
        <meshStandardMaterial color={fp} roughness={0.7} />
      </mesh>
      {[-1, 1].map((sy, i) => (
        <group key={i}>
          {/* Eyes */}
          <mesh position={[0.44, 0.52, sy * 0.1]}>
            <sphereGeometry args={[0.034, 10, 8]} />
            <meshStandardMaterial color="#cc2244" roughness={0.2} metalness={0.1} />
          </mesh>
          <mesh position={[0.456, 0.52, sy * 0.1]}>
            <sphereGeometry args={[0.02, 8, 6]} />
            <meshStandardMaterial color="#220011" roughness={0.5} />
          </mesh>
          <mesh position={[0.462, 0.528, sy * 0.1 + 0.013]}>
            <sphereGeometry args={[0.01, 6, 4]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          {/* Big ears */}
          <mesh position={[0.26, 0.82, sy * 0.1]}>
            <cylinderGeometry args={[0.04, 0.055, 0.48, 10]} />
            <meshStandardMaterial color={fc} roughness={0.85} />
          </mesh>
          <mesh position={[0.26, 1.07, sy * 0.1]}>
            <sphereGeometry args={[0.04, 8, 6]} />
            <meshStandardMaterial color={fc} roughness={0.85} />
          </mesh>
          <mesh position={[0.26, 0.82, sy * 0.1]}>
            <cylinderGeometry args={[0.024, 0.034, 0.42, 10]} />
            <meshStandardMaterial color={fp} roughness={0.8} />
          </mesh>
          {/* Paws */}
          <mesh position={[0.24, -0.04, sy * 0.13]} scale={[0.9, 0.6, 1.3]}>
            <sphereGeometry args={[0.065, 10, 8]} />
            <meshStandardMaterial color={fc} roughness={0.85} />
          </mesh>
          <mesh position={[-0.22, -0.04, sy * 0.16]} scale={[0.8, 0.52, 1.6]}>
            <sphereGeometry args={[0.085, 10, 8]} />
            <meshStandardMaterial color={fc} roughness={0.85} />
          </mesh>
        </group>
      ))}
      {/* Tail */}
      <mesh position={[-0.36, 0.28, 0]}>
        <sphereGeometry args={[0.065, 10, 8]} />
        <meshStandardMaterial color={fc} roughness={0.85} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.006, 0]}>
        <circleGeometry args={[0.2, 12]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.18} depthWrite={false} />
      </mesh>
    </group>
  )
}

const PET_MESHES = { cat: CatMesh, dog: DogMesh, bunny: BunnyMesh }

export default function Pet({ avatarRef }) {
  const petId = useStore((s) => s.petId)
  const groupRef = useRef()
  const petPos = useRef(new THREE.Vector3(10, 0, 9))
  const petAngle = useRef(0)

  const PetMesh = petId ? PET_MESHES[petId] : null

  useFrame((_, dt) => {
    if (!groupRef.current || !PetMesh || !avatarRef?.current) return
    dt = Math.min(dt, 0.05)

    const avatarPos = avatarRef.current.position
    const angle = avatarRef.current.rotation.y

    const tx = avatarPos.x + Math.cos(angle + Math.PI) * 1.4
    const tz = avatarPos.z + Math.sin(angle + Math.PI) * 1.4

    petPos.current.x += (tx - petPos.current.x) * 0.05
    petPos.current.z += (tz - petPos.current.z) * 0.05

    const dx = tx - petPos.current.x
    const dz = tz - petPos.current.z
    if (Math.abs(dx) > 0.02 || Math.abs(dz) > 0.02) {
      petAngle.current = Math.atan2(dx, dz)
    }

    const bob = Math.abs(Math.sin(performance.now() / 500)) * 0.04
    groupRef.current.position.set(petPos.current.x, bob, petPos.current.z)
    groupRef.current.rotation.y = petAngle.current
  })

  if (!PetMesh) return null

  return (
    <group ref={groupRef} scale={[0.82, 0.82, 0.82]}>
      <PetMesh />
    </group>
  )
}
