import { useRef, useEffect } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import useStore, { CATALOG } from '../../store/useStore'
import { useKeyboard } from '../../hooks/useKeyboard'
import { RW, RD, EST_D, EST_H, CELL, CAM_H, CAM_V } from '../../data/constants'

// ── Kirby ────────────────────────────────────────────
function KirbyMesh() {
  const starRef = useRef()
  useFrame(({ clock }) => {
    if (starRef.current) starRef.current.rotation.y = clock.getElapsedTime() * 3.8
  })
  return (
    <group>
      {/* Body */}
      <mesh position={[0, 0.42, 0]} scale={[1, 0.9, 1]} castShadow>
        <sphereGeometry args={[0.42, 20, 16]} />
        <meshStandardMaterial color="#ff88cc" roughness={0.7} />
      </mesh>
      {/* Belly */}
      <mesh position={[0, 0.37, 0.27]} scale={[1, 0.78, 0.5]}>
        <sphereGeometry args={[0.27, 14, 10]} />
        <meshStandardMaterial color="#ffd8ee" roughness={0.8} />
      </mesh>
      {/* Eyes & cheeks */}
      {[-1, 1].map((sx, i) => (
        <group key={i}>
          <mesh position={[sx * 0.27, 0.45, 0.28]} scale={[1, 0.54, 1]}>
            <sphereGeometry args={[0.13, 12, 10]} />
            <meshStandardMaterial color="#ff3388" roughness={0.8} />
          </mesh>
          <mesh position={[sx * 0.15, 0.56, 0.32]} scale={[0.8, 1.34, 0.48]}>
            <sphereGeometry args={[0.132, 14, 10]} />
            <meshStandardMaterial color="#4466ff" roughness={0.3} />
          </mesh>
          <mesh position={[sx * 0.15, 0.56, 0.37]}>
            <sphereGeometry args={[0.072, 12, 10]} />
            <meshStandardMaterial color="#111133" roughness={0.5} />
          </mesh>
          <mesh position={[sx * 0.15 + 0.036, 0.578, 0.41]}>
            <sphereGeometry args={[0.032, 8, 6]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          {/* Feet */}
          <mesh position={[sx * 0.19, 0.065, 0.1]} scale={[0.84, 0.42, 1.4]} castShadow>
            <sphereGeometry args={[0.16, 14, 10]} />
            <meshStandardMaterial color="#ff4488" roughness={0.7} />
          </mesh>
          {/* Arms */}
          <mesh position={[sx * 0.44, 0.43, 0.018]} scale={[0.68, 0.96, 0.6]}>
            <sphereGeometry args={[0.12, 12, 10]} />
            <meshStandardMaterial color="#ff88cc" roughness={0.7} />
          </mesh>
        </group>
      ))}
      {/* Mouth */}
      <mesh position={[0, 0.37, 0.4]} rotation={[Math.PI, 0, 0]}>
        <torusGeometry args={[0.058, 0.021, 8, 14, Math.PI]} />
        <meshStandardMaterial color="#cc1144" roughness={0.8} />
      </mesh>
      {/* Star */}
      <mesh ref={starRef} position={[0.2, 1.0, 0.018]}>
        <octahedronGeometry args={[0.092]} />
        <meshStandardMaterial color="#ffee22" emissive="#ffcc00" emissiveIntensity={0.7} roughness={0.3} />
      </mesh>
      {/* Shadow */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.009, 0]}>
        <circleGeometry args={[0.31, 16]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.2} depthWrite={false} />
      </mesh>
    </group>
  )
}

// ── Waddle Dee ───────────────────────────────────────
function WaddleMesh() {
  return (
    <group>
      <mesh position={[0, 0.36, 0]} scale={[1, 0.86, 1]} castShadow>
        <sphereGeometry args={[0.36, 18, 14]} />
        <meshStandardMaterial color="#ffaa44" roughness={0.75} />
      </mesh>
      <mesh position={[0, 0.31, 0.22]} scale={[1, 0.76, 0.5]}>
        <sphereGeometry args={[0.22, 14, 10]} />
        <meshStandardMaterial color="#ffcc88" roughness={0.8} />
      </mesh>
      {[-1, 1].map((sx, i) => (
        <group key={i}>
          <mesh position={[sx * 0.132, 0.48, 0.29]} scale={[0.81, 1.3, 0.48]}>
            <sphereGeometry args={[0.106, 12, 10]} />
            <meshStandardMaterial color="#3355ff" roughness={0.3} />
          </mesh>
          <mesh position={[sx * 0.17, 0.065, 0.1]} scale={[0.82, 0.41, 1.32]} castShadow>
            <sphereGeometry args={[0.132, 12, 10]} />
            <meshStandardMaterial color="#ff7733" roughness={0.7} />
          </mesh>
        </group>
      ))}
      <mesh position={[0, 0.42, 0.11]} rotation={[0.48, 0, 0]}>
        <torusGeometry args={[0.23, 0.05, 8, 22]} />
        <meshStandardMaterial color="#ff2222" roughness={0.7} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.009, 0]}>
        <circleGeometry args={[0.28, 14]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.17} depthWrite={false} />
      </mesh>
    </group>
  )
}

// ── Meta Knight ─────────────────────────────────────
function MetaMesh() {
  return (
    <group>
      <mesh position={[0, 0.38, 0]} scale={[1, 0.92, 1]} castShadow>
        <sphereGeometry args={[0.38, 18, 14]} />
        <meshStandardMaterial color="#3322aa" roughness={0.5} metalness={0.2} />
      </mesh>
      <mesh position={[0, 0.43, 0.21]} scale={[0.88, 0.66, 0.46]}>
        <sphereGeometry args={[0.28, 14, 10]} />
        <meshStandardMaterial color="#ffdd44" roughness={0.7} />
      </mesh>
      {[-1, 1].map((sx, i) => (
        <group key={i}>
          <mesh position={[sx * 0.095, 0.45, 0.37]}>
            <sphereGeometry args={[0.08, 10, 8]} />
            <meshStandardMaterial color="#ff2222" emissive="#ff0000" emissiveIntensity={1.2} roughness={0.3} />
          </mesh>
          <mesh position={[sx * 0.52, 0.5, -0.11]} rotation={[0, 0, sx * 0.24]} castShadow>
            <boxGeometry args={[0.074, 0.68, 0.86]} />
            <meshStandardMaterial color="#2244cc" roughness={0.5} metalness={0.3} />
          </mesh>
          <mesh position={[sx * 0.17, 0.065, 0.1]} scale={[0.82, 0.41, 1.32]} castShadow>
            <sphereGeometry args={[0.13, 12, 10]} />
            <meshStandardMaterial color="#5522bb" roughness={0.6} />
          </mesh>
        </group>
      ))}
      <mesh position={[0, 0.26, -0.23]} rotation={[0.34, 0, 0]} castShadow>
        <boxGeometry args={[0.96, 0.74, 0.17]} />
        <meshStandardMaterial color="#2255cc" roughness={0.5} metalness={0.2} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.009, 0]}>
        <circleGeometry args={[0.28, 14]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.19} depthWrite={false} />
      </mesh>
    </group>
  )
}

// ── Dedede ───────────────────────────────────────────
function DededeMesh() {
  return (
    <group>
      <mesh position={[0, 0.5, 0]} scale={[1, 0.85, 1]} castShadow>
        <sphereGeometry args={[0.5, 20, 16]} />
        <meshStandardMaterial color="#4477ff" roughness={0.6} />
      </mesh>
      <mesh position={[0, 0.46, 0.3]} scale={[1, 0.78, 0.52]}>
        <sphereGeometry args={[0.33, 14, 10]} />
        <meshStandardMaterial color="#ffcc88" roughness={0.8} />
      </mesh>
      {[-1, 1].map((sx, i) => (
        <group key={i}>
          <mesh position={[sx * 0.16, 0.59, 0.33]} scale={[0.86, 1.3, 0.5]}>
            <sphereGeometry args={[0.118, 12, 10]} />
            <meshStandardMaterial color="#222266" roughness={0.3} />
          </mesh>
          <mesh position={[sx * 0.53, 0.5, 0.046]} scale={[0.73, 1.02, 0.66]} castShadow>
            <sphereGeometry args={[0.15, 12, 10]} />
            <meshStandardMaterial color="#3366ee" roughness={0.6} />
          </mesh>
          <mesh position={[sx * 0.22, 0.065, 0.11]} scale={[0.88, 0.42, 1.34]} castShadow>
            <sphereGeometry args={[0.17, 14, 10]} />
            <meshStandardMaterial color="#2255cc" roughness={0.6} />
          </mesh>
        </group>
      ))}
      {/* Crown */}
      <mesh position={[0, 0.86, 0]}>
        <boxGeometry args={[0.74, 0.11, 0.32]} />
        <meshStandardMaterial color="#ffcc00" roughness={0.4} metalness={0.5} />
      </mesh>
      {[-0.26, -0.13, 0, 0.13, 0.26].map((x, i) => (
        <mesh key={i} position={[x, 0.94, 0]}>
          <boxGeometry args={[0.092, 0.2, 0.092]} />
          <meshStandardMaterial color="#ffee22" roughness={0.3} metalness={0.5} />
        </mesh>
      ))}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.009, 0]}>
        <circleGeometry args={[0.36, 16]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.21} depthWrite={false} />
      </mesh>
    </group>
  )
}

const CHAR_MESHES = {
  kirby:  KirbyMesh,
  waddle: WaddleMesh,
  meta:   MetaMesh,
  dedede: DededeMesh,
}

// ── Avatar controller ────────────────────────────────
export default function Avatar({ joystickAxis }) {
  const charId = useStore((s) => s.charId)
  const items  = useStore((s) => s.items)
  const mode   = useStore((s) => s.mode)

  const CharMesh = CHAR_MESHES[charId] || KirbyMesh
  const groupRef = useRef()
  const keys = useKeyboard()

  const posRef  = useRef(new THREE.Vector3(RW / 2, 0, RD * 0.65))
  const velY    = useRef(0)
  const angleRef = useRef(0)
  const bobT    = useRef(0)

  const fwd = new THREE.Vector3(Math.sin(CAM_H), 0, Math.cos(CAM_H))
  const rgt = new THREE.Vector3(Math.cos(CAM_H), 0, -Math.sin(CAM_H))

  function groundY() {
    return posRef.current.z < EST_D + 0.5 ? EST_H : 0
  }

  function collides(nx, nz) {
    const mg = 0.42
    if (nx < mg || nz < mg || nz > RD - mg || nx > RW - mg) return true
    for (const it of items) {
      const def = CATALOG.find((c) => c.id === it.id)
      if (!def) continue
      const iw = def.W * CELL, id = def.D * CELL, kr = 0.46
      if (nx + kr > it.gx + 0.08 && nx - kr < it.gx + iw - 0.08 &&
          nz + kr > it.gz + 0.08 && nz - kr < it.gz + id - 0.08) return true
    }
    return false
  }

  useFrame((_, dt) => {
    if (!groupRef.current || mode !== 'play') return
    dt = Math.min(dt, 0.05)
    const spd = 3.8 * dt
    const mv = new THREE.Vector3()
    let moved = false

    const ax = joystickAxis?.current?.x || 0
    const ay = joystickAxis?.current?.y || 0

    if (ax || ay) {
      mv.addScaledVector(rgt, ax).addScaledVector(fwd, ay)
      moved = true
      const ln = mv.length()
      if (ln > 0) mv.multiplyScalar(spd * Math.min(ln, 1) / ln)
    } else {
      if (keys.current.u) mv.sub(fwd)
      if (keys.current.d) mv.add(fwd)
      if (keys.current.r) mv.add(rgt)
      if (keys.current.l) mv.sub(rgt)
      if (keys.current.u || keys.current.d || keys.current.r || keys.current.l) {
        moved = true
        mv.normalize().multiplyScalar(spd)
      }
    }

    if (keys.current.space) {
      const gy = groundY()
      if (velY.current < 0.01 && Math.abs(posRef.current.y - gy) < 0.18) {
        velY.current = 5.2
        keys.current.space = false
      }
    }

    if (moved) {
      const ta = Math.atan2(mv.x, mv.z)
      let da = ta - angleRef.current
      while (da > Math.PI) da -= Math.PI * 2
      while (da < -Math.PI) da += Math.PI * 2
      angleRef.current += da * Math.min(1, dt * 14)
    }

    const nx = posRef.current.x + mv.x
    if (!collides(nx, posRef.current.z)) posRef.current.x = nx
    const nz = posRef.current.z + mv.z
    if (!collides(posRef.current.x, nz)) posRef.current.z = nz

    velY.current -= 14 * dt
    posRef.current.y += velY.current * dt
    const gy = groundY()
    if (posRef.current.y <= gy) { posRef.current.y = gy; velY.current = 0 }

    if (moved) bobT.current += dt * 9
    const bob = moved ? Math.abs(Math.sin(bobT.current)) * 0.08 : 0

    groupRef.current.position.set(posRef.current.x, posRef.current.y + bob, posRef.current.z)
    groupRef.current.rotation.y = angleRef.current
  })

  // Expose position for camera
  useFrame(({ camera }) => {
    // Camera follows avatar — smooth
  })

  return (
    <group ref={groupRef}>
      <CharMesh />
    </group>
  )
}

// Export position ref getter for camera
export function useAvatarPosition() {
  // Will be wired through store or ref forwarding
}
