import { useRef, useState } from 'react'
import useStore, { CATALOG, FLOOR_STYLES, WALL_COLORS, CHARS, PETS } from '../store/useStore'
import { useJoystick } from '../hooks/useJoystick'

const TABS = [
  { id: 'mbl', label: 'Meuble',  icon: '🛋' },
  { id: 'dec', label: 'Déco',    icon: '🌸' },
  { id: 'lum', label: 'Lumière', icon: '💡' },
  { id: 'sdb', label: 'SdB',     icon: '🛁' },
  { id: 'jrd', label: 'Jardin',  icon: '🌳' },
  { id: 'sol', label: 'Sol',     icon: '🪟' },
  { id: 'mur', label: 'Mur',     icon: '🧱' },
]

// ── Topbar ───────────────────────────────────────────
function Topbar() {
  const gems   = useStore((s) => s.gems)
  const coins  = useStore((s) => s.coins)

  const save = () => {
    const state = useStore.getState()
    localStorage.setItem('kirby-house-manual', JSON.stringify({
      floorStyle: state.floorStyle,
      wallColors: state.wallColors,
      items: state.items,
      charId: state.charId,
      petId: state.petId,
    }))
    showToast('Sauvegardé ! 💾')
  }

  return (
    <div style={styles.topbar}>
      <div style={{ ...styles.chip, background: 'rgba(42,120,210,.85)', border: '1.5px solid #7ab8e8' }}>
        💎 {gems}
      </div>
      <div style={{ ...styles.chip, background: 'rgba(180,100,8,.85)', border: '1.5px solid #f0b429' }}>
        🪙 {coins}
      </div>
      <div style={styles.roomName}>🏠 Ma Maison Kirby</div>
      <button style={styles.saveBtn} onClick={save}>Sauver</button>
    </div>
  )
}

// ── Zoom controls ────────────────────────────────────
function ZoomControls() {
  const setZoom   = useStore((s) => s.setZoom)
  const resetZoom = useStore((s) => s.resetZoom)
  const zoom      = useStore((s) => s.zoomLevel)
  const timerRef  = useRef(null)

  const startZoom = (dir) => {
    setZoom(zoom + dir * -1.5)
    timerRef.current = setInterval(() => setZoom(useStore.getState().zoomLevel + dir * -1.5), 60)
  }
  const stopZoom = () => clearInterval(timerRef.current)

  return (
    <div style={styles.zoomCtrl}>
      <button style={styles.zBtn}
        onMouseDown={() => startZoom(-1)} onMouseUp={stopZoom}
        onTouchStart={(e) => { e.preventDefault(); startZoom(-1) }} onTouchEnd={stopZoom}>+</button>
      <button style={styles.zBtn} onClick={resetZoom} title="Reset vue">⌂</button>
      <button style={styles.zBtn}
        onMouseDown={() => startZoom(1)} onMouseUp={stopZoom}
        onTouchStart={(e) => { e.preventDefault(); startZoom(1) }} onTouchEnd={stopZoom}>−</button>
    </div>
  )
}

// ── Perso button + overlay ───────────────────────────
function PersoOverlay() {
  const open    = useStore((s) => s.persoOpen)
  const setOpen = useStore((s) => s.setPersoOpen)
  const charId  = useStore((s) => s.charId)
  const petId   = useStore((s) => s.petId)
  const setChar = useStore((s) => s.setChar)
  const setPet  = useStore((s) => s.setPet)

  if (!open) return null

  return (
    <div style={styles.overlay} onClick={() => setOpen(false)}>
      <div style={styles.overlayCard} onClick={(e) => e.stopPropagation()}>
        <h2 style={styles.overlayTitle}>Personnage & Animal</h2>

        <div style={styles.sectionLabel}>PERSO</div>
        <div style={styles.pgrid}>
          {CHARS.map((c) => (
            <button
              key={c.id}
              style={{ ...styles.pbtn, ...(charId === c.id ? styles.pbtnOn : {}) }}
              onClick={() => setChar(c.id)}
            >
              <span style={{ fontSize: 26, display: 'block' }}>{c.ico}</span>
              {c.name}
            </button>
          ))}
        </div>

        <div style={{ ...styles.sectionLabel, marginTop: 12 }}>ANIMAL</div>
        <div style={styles.pgrid}>
          <button
            style={{ ...styles.pbtn, ...(petId === null ? styles.pbtnOn : {}) }}
            onClick={() => setPet(null)}
          >
            <span style={{ fontSize: 26, display: 'block' }}>🚫</span>
            Aucun
          </button>
          {PETS.map((p) => (
            <button
              key={p.id}
              style={{ ...styles.pbtn, ...(petId === p.id ? styles.pbtnOn : {}) }}
              onClick={() => setPet(p.id)}
            >
              <span style={{ fontSize: 26, display: 'block' }}>{p.ico}</span>
              {p.name}
            </button>
          ))}
        </div>

        <button style={styles.closeBtn} onClick={() => setOpen(false)}>▼ Fermer</button>
      </div>
    </div>
  )
}

// ── Object action menu ───────────────────────────────
function ObjectMenu() {
  const selectedUID = useStore((s) => s.selectedUID)
  const rotateItem  = useStore((s) => s.rotateItem)
  const removeItem  = useStore((s) => s.removeItem)
  const startDrag   = useStore((s) => s.startDrag)
  const deselect    = useStore((s) => s.deselect)

  if (!selectedUID) return null

  return (
    <div style={styles.objMenu}>
      <button style={{ ...styles.omBtn, borderColor: '#c8860a', color: '#f0c060' }}
        onClick={() => { rotateItem(selectedUID) }}>
        ↻<span style={styles.omLabel}>Tourner</span>
      </button>
      <button style={{ ...styles.omBtn, borderColor: '#4a9acc', color: '#aaddff' }}
        onClick={() => { startDrag(selectedUID) }}>
        ⇔<span style={styles.omLabel}>Déplacer</span>
      </button>
      <button style={{ ...styles.omBtn, borderColor: '#cc4444', color: '#ffaaaa' }}
        onClick={() => { removeItem(selectedUID) }}>
        ✕<span style={styles.omLabel}>Retirer</span>
      </button>
      <button style={{ ...styles.omBtn, borderColor: '#666', color: '#aaa' }}
        onClick={deselect}>
        ✕
      </button>
    </div>
  )
}

// ── Wall color picker ────────────────────────────────
function WallPicker({ onClose }) {
  const wallColors   = useStore((s) => s.wallColors)
  const setWallColor = useStore((s) => s.setWallColor)
  const [side, setSide] = useState('back')

  return (
    <div style={styles.wallMenu}>
      <div style={styles.wallLabel}>Mur — couleur</div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
        {['back', 'left', 'right'].map((s, i) => (
          <button
            key={s}
            style={{
              ...styles.sideBtn,
              background: wallColors[s],
              border: `2px solid ${side === s ? '#f0c060' : 'rgba(139,92,30,.4)'}`,
            }}
            onClick={() => setSide(s)}
          >
            {['Arrière', 'Gauche', 'Droit'][i]}
          </button>
        ))}
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
        {WALL_COLORS.map((col) => (
          <div
            key={col}
            style={{
              width: 26, height: 26, borderRadius: 6, background: col, cursor: 'pointer',
              border: `2.5px solid ${wallColors[side] === col ? '#f0c060' : 'rgba(255,255,255,.2)'}`,
              transform: wallColors[side] === col ? 'scale(1.18)' : 'scale(1)',
            }}
            onClick={() => setWallColor(side, col)}
          />
        ))}
      </div>
    </div>
  )
}

// ── Bottom panel ─────────────────────────────────────
function Panel() {
  const open       = useStore((s) => s.panelOpen)
  const togglePanel= useStore((s) => s.togglePanel)
  const activeTab  = useStore((s) => s.activeTab)
  const setTab     = useStore((s) => s.setTab)
  const floorStyle = useStore((s) => s.floorStyle)
  const setFloor   = useStore((s) => s.setFloor)
  const startPlace = useStore((s) => s.startPlace)
  const cancelPlace= useStore((s) => s.cancelPlace)
  const mode       = useStore((s) => s.mode)
  const pendingDef = useStore((s) => s.pendingDef)

  const [showWall, setShowWall] = useState(false)

  const handleTab = (id) => {
    if (id === 'mur') { setShowWall(!showWall); return }
    setShowWall(false)
    setTab(id)
  }

  const handleItemClick = (def) => {
    if (mode === 'place' && pendingDef?.id === def.id) {
      cancelPlace()
    } else {
      startPlace(def)
    }
  }

  const catalogItems = activeTab === 'sol' || activeTab === 'mur'
    ? []
    : CATALOG.filter((c) => c.cat === activeTab)

  return (
    <>
      {/* Toggle button */}
      <button style={{ ...styles.panelToggle, bottom: open ? 128 : 0 }} onClick={togglePanel}>
        {open ? '▼' : '▲'}
      </button>

      <div style={{ ...styles.panel, transform: open ? 'translateY(0)' : 'translateY(100%)' }}>
        {/* Tabs */}
        <div style={styles.tabs}>
          {TABS.map((tab) => (
            <button
              key={tab.id}
              style={{ ...styles.tab, ...(activeTab === tab.id || (tab.id === 'mur' && showWall) ? styles.tabOn : {}) }}
              onClick={() => handleTab(tab.id)}
            >
              <span style={{ fontSize: 16 }}>{tab.icon}</span>
              <span style={{ fontSize: '5.5px' }}>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Wall picker */}
        {showWall && <WallPicker onClose={() => setShowWall(false)} />}

        {/* Floor picker */}
        {activeTab === 'sol' && (
          <div style={styles.shelf}>
            {FLOOR_STYLES.map((fl, i) => (
              <div
                key={fl.id}
                style={{ ...styles.swatchItem, ...(floorStyle === i ? styles.swatchOn : {}) }}
                onClick={() => setFloor(i)}
              >
                <div style={{ width: 48, height: 32, borderRadius: 7, background: fl.color, border: '1.5px solid rgba(240,192,96,.2)' }} />
                <span style={{ fontSize: '6px', color: '#f0c060', fontWeight: 700, textAlign: 'center' }}>{fl.name}</span>
              </div>
            ))}
          </div>
        )}

        {/* Catalog items */}
        {catalogItems.length > 0 && (
          <div style={styles.shelf}>
            {catalogItems.map((def) => {
              const isActive = mode === 'place' && pendingDef?.id === def.id
              return (
                <div
                  key={def.id}
                  style={{ ...styles.itemCard, ...(isActive ? styles.itemCardOn : {}) }}
                  onClick={() => handleItemClick(def)}
                >
                  <span style={{ fontSize: 24 }}>{def.ico}</span>
                  <span style={{ fontSize: '6px', color: '#f0c060', fontWeight: 700, textAlign: 'center', lineHeight: 1.2 }}>{def.name}</span>
                  <span style={{ fontSize: '5px', color: 'rgba(240,192,96,.5)', fontWeight: 700 }}>{def.price}🪙</span>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </>
  )
}

// ── Place hint ───────────────────────────────────────
function PlaceHint() {
  const mode       = useStore((s) => s.mode)
  const pendingDef = useStore((s) => s.pendingDef)
  const cancel     = useStore((s) => s.cancelPlace)

  if (mode !== 'place' && mode !== 'drag') return null

  return (
    <div style={styles.placeHint}>
      {mode === 'place'
        ? `${pendingDef?.name || 'Objet'} — Glisse pour placer · Tape pour poser`
        : 'Glisse pour déplacer · Relâche pour poser'}
      <button style={styles.hintCancel} onClick={cancel}>✕ Annuler</button>
    </div>
  )
}

// ── Toast ────────────────────────────────────────────
let toastTimeout = null
function showToast(msg) {
  const el = document.getElementById('kirby-toast')
  if (!el) return
  el.textContent = msg
  el.style.opacity = '1'
  el.style.transform = 'translateX(-50%) scale(1)'
  clearTimeout(toastTimeout)
  toastTimeout = setTimeout(() => {
    el.style.opacity = '0'
    el.style.transform = 'translateX(-50%) scale(0.9)'
  }, 1800)
}

function Toast() {
  return (
    <div
      id="kirby-toast"
      style={{
        position: 'absolute', top: 54, left: '50%',
        transform: 'translateX(-50%) scale(0.9)',
        background: 'rgba(26,12,0,.92)',
        border: '1.5px solid #8b5c1e',
        borderRadius: 10, padding: '4px 14px',
        fontSize: 10, fontWeight: 700, color: '#f0c060',
        opacity: 0, pointerEvents: 'none', zIndex: 90,
        transition: 'opacity .15s, transform .15s',
        whiteSpace: 'nowrap', fontFamily: 'Georgia,serif',
      }}
    />
  )
}

// ── Zone tag ─────────────────────────────────────────
function ZoneTag() {
  const [zone, setZone] = useState('Salon')
  // Updated from Avatar via store or ref — simplified here
  return (
    <div style={styles.zoneTag}>{zone}</div>
  )
}

// ── Joystick ─────────────────────────────────────────
export function Joystick({ axisRef }) {
  const baseRef = useRef()
  const nubRef  = useRef()
  useJoystick(baseRef, nubRef)
  // Copy internal axis to the passed axisRef
  // (hook already writes to its own ref; we reuse baseRef/nubRef)
  return (
    <div ref={baseRef} style={styles.joy}>
      <div ref={nubRef} style={styles.jNub} />
    </div>
  )
}

// ── Jump button ──────────────────────────────────────
function JumpBtn() {
  const handleJump = (e) => {
    e.preventDefault()
    window.__kirbyJump?.()
  }
  return (
    <button style={styles.jumpBtn} onTouchStart={handleJump} onClick={handleJump}>✨</button>
  )
}

// ── Main UI export ───────────────────────────────────
export default function UI() {
  const setPersoOpen = useStore((s) => s.setPersoOpen)

  return (
    <>
      <Topbar />
      <ZoomControls />
      <button style={styles.persoBtn} onClick={() => setPersoOpen(true)}>🐾</button>
      <ZoneTag />
      <PlaceHint />
      <ObjectMenu />
      <Panel />
      <PersoOverlay />
      <Toast />
    </>
  )
}

// ── Styles object ────────────────────────────────────
const styles = {
  topbar: {
    position: 'absolute', top: 0, left: 0, right: 0, height: 44, zIndex: 50,
    background: 'linear-gradient(180deg,rgba(42,21,5,.96),rgba(26,12,0,.92))',
    borderBottom: '2px solid rgba(200,134,10,.5)',
    display: 'flex', alignItems: 'center', padding: '0 10px', gap: 8,
    backdropFilter: 'blur(4px)',
  },
  chip: {
    borderRadius: 20, padding: '3px 9px', fontSize: 11, fontWeight: 700,
    display: 'flex', alignItems: 'center', gap: 3, whiteSpace: 'nowrap', color: '#fff',
  },
  roomName: {
    flex: 1, textAlign: 'center', fontSize: 12, color: '#f0c060',
    fontWeight: 700, fontFamily: 'Georgia,serif', letterSpacing: '.5px',
  },
  saveBtn: {
    borderRadius: 14, padding: '4px 12px', fontSize: 10, fontWeight: 700,
    background: 'linear-gradient(135deg,#5c3610,#3a1f06)', border: '1.5px solid #c8860a',
    color: '#f0c060', cursor: 'pointer', whiteSpace: 'nowrap',
  },
  zoomCtrl: {
    position: 'absolute', top: 54, left: 10, zIndex: 40,
    display: 'flex', flexDirection: 'column', gap: 4,
  },
  zBtn: {
    width: 34, height: 34, borderRadius: '50%',
    background: 'linear-gradient(135deg,rgba(42,21,5,.92),rgba(26,12,0,.95))',
    border: '1.5px solid rgba(139,92,30,.6)', color: '#f0c060',
    fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center',
    justifyContent: 'center', cursor: 'pointer', boxShadow: '0 2px 8px rgba(0,0,0,.4)',
  },
  persoBtn: {
    position: 'absolute', top: 54, right: 10, zIndex: 40,
    width: 36, height: 36, borderRadius: '50%',
    background: 'linear-gradient(135deg,#3d1f0a,#2a1505)',
    border: '1.5px solid rgba(139,92,30,.6)', fontSize: 18, cursor: 'pointer',
  },
  zoneTag: {
    position: 'absolute', bottom: 140, left: 10, zIndex: 30,
    fontSize: 9, fontWeight: 700, color: 'rgba(240,192,96,.7)',
    background: 'rgba(0,0,0,.45)', borderRadius: 8, padding: '3px 8px',
    pointerEvents: 'none',
  },
  joy: {
    position: 'absolute', left: 10, bottom: 10, zIndex: 40,
    width: 80, height: 80, borderRadius: '50%',
    background: 'rgba(139,92,30,.15)', border: '2.5px solid rgba(139,92,30,.4)',
    touchAction: 'none', userSelect: 'none',
  },
  jNub: {
    position: 'absolute', top: '50%', left: '50%',
    transform: 'translate(-50%,-50%)',
    width: 38, height: 38, borderRadius: '50%',
    background: 'radial-gradient(circle at 35% 35%,#f0c060,#c8860a)',
    border: '2.5px solid rgba(255,255,255,.8)',
    boxShadow: '0 2px 8px rgba(0,0,0,.4)', pointerEvents: 'none',
  },
  jumpBtn: {
    position: 'absolute', right: 10, bottom: 10, zIndex: 40,
    width: 52, height: 52, borderRadius: '50%',
    background: 'radial-gradient(circle at 35% 35%,#ffe888,#c8a020)',
    border: '2.5px solid rgba(255,255,255,.8)', fontSize: 22, cursor: 'pointer',
    boxShadow: '0 3px 12px rgba(0,0,0,.5)',
  },
  panel: {
    position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 35,
    background: 'linear-gradient(180deg,rgba(42,21,5,.97),rgba(20,10,0,.99))',
    borderTop: '2px solid rgba(200,134,10,.5)',
    transition: 'transform .25s ease',
  },
  panelToggle: {
    position: 'absolute', right: 12, zIndex: 36,
    width: 34, height: 18, borderRadius: '8px 8px 0 0',
    background: 'rgba(200,134,10,.7)', border: '1.5px solid rgba(200,134,10,.9)',
    borderBottom: 'none', fontSize: 11, cursor: 'pointer', color: '#fff', fontWeight: 700,
    transition: 'bottom .25s ease',
  },
  tabs: {
    display: 'flex', height: 40, overflowX: 'auto',
    background: 'linear-gradient(180deg,rgba(55,28,8,.9),rgba(38,18,5,.95))',
    borderBottom: '1px solid rgba(139,92,30,.3)',
  },
  tab: {
    flexShrink: 0, minWidth: 52, display: 'flex', flexDirection: 'column',
    alignItems: 'center', justifyContent: 'center', gap: 1,
    fontSize: '5.5px', fontWeight: 700, color: 'rgba(240,192,96,.4)',
    borderBottom: '2.5px solid transparent', cursor: 'pointer', padding: '0 4px',
    background: 'transparent', border: 'none', borderBottom: '2.5px solid transparent',
  },
  tabOn: {
    color: '#f0c060', borderBottom: '2.5px solid #c8860a',
  },
  shelf: {
    height: 92, display: 'flex', alignItems: 'center', gap: 5,
    padding: '4px 8px', overflowX: 'auto',
  },
  swatchItem: {
    flexShrink: 0, width: 70, height: 80, borderRadius: 12, cursor: 'pointer',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    justifyContent: 'center', gap: 4,
    background: 'rgba(255,255,255,.04)', border: '1.5px solid rgba(139,92,30,.28)',
  },
  swatchOn: {
    background: 'rgba(200,134,10,.16)', border: '1.5px solid #c8860a',
  },
  itemCard: {
    flexShrink: 0, width: 70, height: 80, borderRadius: 12, cursor: 'pointer',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    justifyContent: 'center', gap: 2,
    background: 'rgba(255,255,255,.04)', border: '1.5px solid rgba(139,92,30,.28)',
  },
  itemCardOn: {
    background: 'rgba(200,134,10,.16)', border: '1.5px solid #c8860a',
  },
  objMenu: {
    position: 'absolute', top: '50%', left: '50%',
    transform: 'translate(-50%, -50%)',
    zIndex: 60, display: 'flex', flexDirection: 'row', gap: 6,
    background: 'linear-gradient(135deg,rgba(26,12,0,.97),rgba(42,21,5,.99))',
    border: '1.5px solid #c8860a', borderRadius: 14, padding: '8px 10px',
    boxShadow: '0 6px 20px rgba(0,0,0,.7)',
  },
  omBtn: {
    width: 44, height: 44, borderRadius: 10, cursor: 'pointer',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    justifyContent: 'center', gap: 1, fontSize: 18, fontWeight: 700,
    background: 'rgba(0,0,0,.4)', border: '1.5px solid',
  },
  omLabel: { fontSize: '6px', fontWeight: 700, opacity: 0.75 },
  wallMenu: {
    padding: '10px 12px',
    borderBottom: '1px solid rgba(139,92,30,.3)',
  },
  wallLabel: {
    fontSize: 8, fontWeight: 700, color: '#f0c060',
    textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8,
  },
  sideBtn: {
    padding: '3px 8px', borderRadius: 8, fontSize: 7, fontWeight: 700,
    color: '#f0c060', cursor: 'pointer',
  },
  placeHint: {
    position: 'absolute', top: 54, left: '50%', transform: 'translateX(-50%)',
    zIndex: 91, background: 'rgba(0,0,0,.82)',
    border: '1.5px solid #c8860a', borderRadius: 10,
    padding: '6px 14px', fontSize: 10, fontWeight: 700, color: '#f0c060',
    fontFamily: 'Georgia,serif', display: 'flex', alignItems: 'center', gap: 10,
    whiteSpace: 'nowrap', pointerEvents: 'auto',
  },
  hintCancel: {
    padding: '2px 8px', borderRadius: 8, fontSize: 9, fontWeight: 700,
    background: 'rgba(180,40,40,.6)', border: '1px solid #cc4444',
    color: '#ffaaaa', cursor: 'pointer',
  },
  overlay: {
    position: 'absolute', inset: 0, zIndex: 100,
    display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
    background: 'rgba(0,0,0,.6)',
  },
  overlayCard: {
    width: '100%', maxWidth: 420,
    background: 'linear-gradient(180deg,#3d1f0a,#2a1505)',
    borderTop: '2px solid #c8860a', borderRadius: '20px 20px 0 0',
    padding: 16, paddingBottom: 24,
  },
  overlayTitle: {
    textAlign: 'center', fontSize: 13, color: '#f0c060',
    fontWeight: 700, marginBottom: 12, fontFamily: 'Georgia,serif',
  },
  sectionLabel: {
    fontSize: 8, fontWeight: 700, color: '#c8860a', letterSpacing: 2,
    textTransform: 'uppercase', borderBottom: '1px solid rgba(139,92,30,.3)',
    paddingBottom: 3, marginBottom: 7,
  },
  pgrid: { display: 'flex', gap: 6, flexWrap: 'wrap' },
  pbtn: {
    padding: '6px 9px', borderRadius: 10,
    border: '1.5px solid rgba(139,92,30,.4)',
    background: 'rgba(255,255,255,.06)', color: '#f0c060',
    fontSize: 8, fontWeight: 700, cursor: 'pointer', minWidth: 62, textAlign: 'center',
  },
  pbtnOn: {
    background: 'rgba(200,134,10,.25)', border: '1.5px solid #c8860a',
  },
  closeBtn: {
    display: 'block', width: '100%', marginTop: 12,
    fontSize: 11, color: 'rgba(240,192,96,.5)', cursor: 'pointer',
    background: 'transparent', border: 'none', textAlign: 'center',
  },
}
