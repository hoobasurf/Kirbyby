import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import useStore, { FLOOR_STYLES } from '../../store/useStore'
import { RW, RD, WH, EST_D, EST_H } from '../../data/constants'

// ── Procedural floor texture ─────────────────────────
function makeHerringboneTexture(c1hex, c2hex) {
  const sz = 256
  const canvas = document.createElement('canvas')
  canvas.width = sz; canvas.height = sz
  const ctx = canvas.getContext('2d')
  ctx.fillStyle = c1hex
  ctx.fillRect(0, 0, sz, sz)

  const pw = 18, pl = 44
  for (let row = -3; row < sz / pl * 2 + 4; row++) {
    for (let col = -3; col < sz / pw * 2 + 4; col++) {
      const even = (row + col) % 2 === 0
      const ang = even ? Math.PI / 4 : -Math.PI / 4
      const ox = col * pw * 2 + (even ? 0 : pw)
      const oy = row * pl
      const cs = Math.cos(ang), sn = Math.sin(ang)
      ctx.setTransform(cs, sn, -sn, cs, ox, oy)
      ctx.fillStyle = even ? c2hex : shadeColor(c1hex, -0.12)
      ctx.fillRect(-pl / 2, -pw / 2, pl, pw)
      ctx.strokeStyle = 'rgba(0,0,0,0.15)'
      ctx.lineWidth = 0.8
      ctx.strokeRect(-pl / 2, -pw / 2, pl, pw)
    }
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0)

  const tex = new THREE.CanvasTexture(canvas)
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping
  tex.repeat.set(RW / 4, RD / 4)
  tex.anisotropy = 4
  return tex
}

function shadeColor(hex, pct) {
  const n = parseInt(hex.replace('#', ''), 16)
  const r = Math.max(0, Math.min(255, ((n >> 16) & 255) + Math.round(255 * pct)))
  const g = Math.max(0, Math.min(255, ((n >> 8) & 255) + Math.round(255 * pct)))
  const b = Math.max(0, Math.min(255, (n & 255) + Math.round(255 * pct)))
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`
}

function makeWallTexture(hexColor) {
  const canvas = document.createElement('canvas')
  canvas.width = 128; canvas.height = 256
  const ctx = canvas.getContext('2d')
  const c2 = shadeColor(hexColor, 0.12)
  for (let y = 0; y < 256; y += 16) {
    ctx.fillStyle = (y % 32 < 16) ? hexColor : c2
    ctx.fillRect(0, y, 128, 16)
  }
  // subtle noise
  for (let i = 0; i < 800; i++) {
    const x = Math.random() * 128, y = Math.random() * 256
    ctx.fillStyle = `rgba(0,0,0,${Math.random() * 0.04})`
    ctx.fillRect(x, y, 1, 1)
  }
  const tex = new THREE.CanvasTexture(canvas)
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping
  tex.repeat.set(6, 3)
  tex.anisotropy = 4
  return tex
}

function makeRoughnessMap() {
  const canvas = document.createElement('canvas')
  canvas.width = 64; canvas.height = 64
  const ctx = canvas.getContext('2d')
  ctx.fillStyle = '#aaa'
  ctx.fillRect(0, 0, 64, 64)
  for (let i = 0; i < 300; i++) {
    const v = Math.floor(Math.random() * 30 + 150)
    ctx.fillStyle = `rgb(${v},${v},${v})`
    ctx.fillRect(Math.random() * 64, Math.random() * 64, 2, 2)
  }
  const tex = new THREE.CanvasTexture(canvas)
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping
  return tex
}

// ── Spotlight for estrade ────────────────────────────
function EstradeSpot({ x }) {
  return (
    <spotLight
      position={[x, WH * 0.85, EST_D * 0.3]}
      target-position={[x, 0, EST_D * 0.5]}
      intensity={80}
      angle={0.35}
      penumbra={0.6}
      color="#ffd080"
      castShadow
      shadow-mapSize={[512, 512]}
      shadow-bias={-0.001}
    />
  )
}

// ── Main Room ────────────────────────────────────────
export default function Room() {
  const floorStyle = useStore((s) => s.floorStyle)
  const wallColors = useStore((s) => s.wallColors)
  const fl = FLOOR_STYLES[floorStyle] || FLOOR_STYLES[0]
  const wt = 0.22 // wall thickness
  const mainD = RD - EST_D

  const floorTex = useMemo(() => makeHerringboneTexture(fl.color, fl.color2), [fl])
  const estradeTex = useMemo(
    () => makeHerringboneTexture(shadeColor(fl.color, -0.1), shadeColor(fl.color2, -0.08)),
    [fl]
  )
  const roughMap = useMemo(() => makeRoughnessMap(), [])

  const wallTexBack  = useMemo(() => makeWallTexture(wallColors.back),  [wallColors.back])
  const wallTexLeft  = useMemo(() => makeWallTexture(wallColors.left),  [wallColors.left])
  const wallTexRight = useMemo(() => makeWallTexture(wallColors.right), [wallColors.right])

  const goldMat = { color: '#d4a017', roughness: 0.3, metalness: 0.7 }
  const glassMat = { color: '#1e5a78', roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.65 }

  // door dims
  const dZ = RD * 0.35, dW = 3.0, dH = 2.7

  return (
    <group>
      {/* ── Lighting ── */}
      <ambientLight intensity={0.7} color="#fff0d0" />
      <directionalLight
        position={[14, 26, 10]}
        intensity={1.4}
        color="#fff8e8"
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-32}
        shadow-camera-right={32}
        shadow-camera-top={32}
        shadow-camera-bottom={-32}
        shadow-camera-far={80}
        shadow-bias={-0.001}
      />
      <directionalLight position={[-8, 5, 14]} intensity={0.4} color="#ffd080" />
      <EstradeSpot x={RW * 0.18} />
      <EstradeSpot x={RW * 0.5} />
      <EstradeSpot x={RW * 0.82} />

      {/* ── Floor main ── */}
      <mesh position={[RW / 2, -0.06, EST_D + mainD / 2]} receiveShadow>
        <boxGeometry args={[RW, 0.12, mainD]} />
        <meshStandardMaterial map={floorTex} roughness={0.75} roughnessMap={roughMap} />
      </mesh>

      {/* ── Estrade ── */}
      <mesh position={[RW / 2, EST_H / 2, EST_D / 2]} castShadow receiveShadow>
        <boxGeometry args={[RW, EST_H, EST_D]} />
        <meshStandardMaterial map={estradeTex} roughness={0.8} roughnessMap={roughMap} />
      </mesh>

      {/* Rebord doré estrade */}
      <mesh position={[RW / 2, EST_H + 0.04, EST_D + 0.05]}>
        <boxGeometry args={[RW + 0.1, 0.08, 0.1]} />
        <meshStandardMaterial {...goldMat} />
      </mesh>

      {/* Marche d'accès */}
      <mesh position={[RW / 2, EST_H * 0.3, EST_D + 0.16]} castShadow receiveShadow>
        <boxGeometry args={[RW, EST_H * 0.6, 0.32]} />
        <meshStandardMaterial map={estradeTex} roughness={0.8} />
      </mesh>

      {/* ── Mur arrière ── */}
      <mesh position={[RW / 2, WH / 2, -wt / 2]} castShadow userData={{ isWall: true }}>
        <boxGeometry args={[RW + wt * 2, WH, wt]} />
        <meshStandardMaterial map={wallTexBack} roughness={0.92} />
      </mesh>
      {/* plinthe */}
      <mesh position={[RW / 2, 0.05, -wt / 2]}>
        <boxGeometry args={[RW + wt * 2, 0.1, wt]} />
        <meshStandardMaterial color={shadeColor(wallColors.back, -0.2)} roughness={0.9} />
      </mesh>
      {/* corniche */}
      <mesh position={[RW / 2, WH - 0.045, -wt / 2]}>
        <boxGeometry args={[RW + wt * 2, 0.09, wt]} />
        <meshStandardMaterial color={shadeColor(wallColors.back, 0.2)} roughness={0.9} />
      </mesh>

      {/* ── Mur gauche ── */}
      <mesh position={[-wt / 2, WH / 2, RD / 2]} castShadow userData={{ isWall: true }}>
        <boxGeometry args={[wt, WH, RD]} />
        <meshStandardMaterial map={wallTexLeft} roughness={0.92} />
      </mesh>
      <mesh position={[-wt / 2, 0.05, RD / 2]}>
        <boxGeometry args={[wt, 0.1, RD]} />
        <meshStandardMaterial color={shadeColor(wallColors.left, -0.2)} roughness={0.9} />
      </mesh>
      <mesh position={[-wt / 2, WH - 0.045, RD / 2]}>
        <boxGeometry args={[wt, 0.09, RD]} />
        <meshStandardMaterial color={shadeColor(wallColors.left, 0.2)} roughness={0.9} />
      </mesh>

      {/* ── Mur droit avec porte vitrée ── */}
      {/* Segment avant porte */}
      {dZ > 0.1 && (
        <mesh position={[RW + wt / 2, WH / 2, dZ / 2]} castShadow userData={{ isWall: true }}>
          <boxGeometry args={[wt, WH, dZ]} />
          <meshStandardMaterial map={wallTexRight} roughness={0.92} />
        </mesh>
      )}
      {/* Segment après porte */}
      {RD - dZ - dW > 0.1 && (
        <mesh position={[RW + wt / 2, WH / 2, dZ + dW + (RD - dZ - dW) / 2]} castShadow userData={{ isWall: true }}>
          <boxGeometry args={[wt, WH, RD - dZ - dW]} />
          <meshStandardMaterial map={wallTexRight} roughness={0.92} />
        </mesh>
      )}
      {/* Dessus porte */}
      <mesh position={[RW + wt / 2, (WH + dH) / 2, RD / 2]} userData={{ isWall: true }}>
        <boxGeometry args={[wt, WH - dH, RD]} />
        <meshStandardMaterial map={wallTexRight} roughness={0.92} />
      </mesh>
      {/* Cadre doré porte */}
      <mesh position={[RW + 0.07, dH / 2, dZ + dW / 2]}>
        <boxGeometry args={[0.12, dH + 0.14, dW + 0.12]} />
        <meshStandardMaterial {...goldMat} />
      </mesh>
      {/* Vitres */}
      {[0, 1].map((i) => (
        <mesh key={i} position={[RW + 0.04, dH / 2, dZ + i * (dW / 2 + 0.05) + dW / 4]}>
          <boxGeometry args={[0.05, dH, dW / 2 - 0.05]} />
          <meshStandardMaterial {...glassMat} side={THREE.DoubleSide} />
        </mesh>
      ))}
      {/* Poignée */}
      <mesh position={[RW + 0.08, dH * 0.42, dZ + dW * 0.82]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.035, 0.035, 0.28, 10]} />
        <meshStandardMaterial {...goldMat} />
      </mesh>
      {/* plinthes mur droit */}
      <mesh position={[RW + wt / 2, 0.05, RD / 2]}>
        <boxGeometry args={[wt, 0.1, RD]} />
        <meshStandardMaterial color={shadeColor(wallColors.right, -0.2)} roughness={0.9} />
      </mesh>
      <mesh position={[RW + wt / 2, WH - 0.045, RD / 2]}>
        <boxGeometry args={[wt, 0.09, RD]} />
        <meshStandardMaterial color={shadeColor(wallColors.right, 0.2)} roughness={0.9} />
      </mesh>

      {/* ── Colonnes art déco estrade ── */}
      {[0.28, RW - 0.28].map((cx, i) => (
        <group key={i}>
          <mesh position={[cx, WH * 0.38, 0.12]} castShadow>
            <cylinderGeometry args={[0.09, 0.11, WH * 0.76, 18]} />
            <meshStandardMaterial {...goldMat} />
          </mesh>
          <mesh position={[cx, WH * 0.76 + 0.045, 0.12]}>
            <boxGeometry args={[0.28, 0.09, 0.28]} />
            <meshStandardMaterial {...goldMat} />
          </mesh>
          <mesh position={[cx, EST_H + 0.045, 0.12]}>
            <boxGeometry args={[0.22, 0.09, 0.22]} />
            <meshStandardMaterial color="#b8860b" roughness={0.3} metalness={0.7} />
          </mesh>
        </group>
      ))}

      {/* ── Fond alcôve ── */}
      <mesh position={[RW / 2, EST_H + WH * 0.36, 0.05]}>
        <boxGeometry args={[RW - 0.52, WH * 0.72, 0.08]} />
        <meshStandardMaterial
          color={shadeColor(wallColors.back, 0.18)}
          roughness={0.92}
        />
      </mesh>
      {/* Corniche alcôve */}
      <mesh position={[RW / 2, EST_H + WH * 0.72 + 0.045, 0.05]}>
        <boxGeometry args={[RW - 0.48, 0.09, 0.16]} />
        <meshStandardMaterial {...goldMat} />
      </mesh>
    </group>
  )
}
