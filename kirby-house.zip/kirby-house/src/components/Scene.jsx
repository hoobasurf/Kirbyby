import { useRef, useState, useCallback } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { OrthographicCamera, Preload } from '@react-three/drei'
import { EffectComposer, Bloom, SMAA, Vignette } from '@react-three/postprocessing'
import * as THREE from 'three'
import useStore, { CATALOG } from '../store/useStore'
import { RW, RD, WH, EST_D, EST_H, CELL, CAM_H, CAM_V } from '../data/constants'
import Room from './room/Room'
import FurnitureInstance from './furniture/FurnitureInstance'
import Ghost from './furniture/Ghost'
import Avatar from './avatar/Avatar'
import Pet from './avatar/Pet'

// ── Invisible ground planes for raycasting ───────────
function GroundPlanes({ onPointerMove, onPointerUp }) {
  return (
    <>
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[RW / 2, 0.01, RD / 2]}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        visible={false}
      >
        <planeGeometry args={[RW * 3, RD * 3]} />
        <meshBasicMaterial />
      </mesh>
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[RW / 2, EST_H + 0.01, EST_D / 2]}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        visible={false}
      >
        <planeGeometry args={[RW * 2, EST_D * 2]} />
        <meshBasicMaterial />
      </mesh>
    </>
  )
}

// ── Camera controller ────────────────────────────────
function CameraController({ avatarRef }) {
  const { camera } = useThree()
  const smoothTarget = useRef(new THREE.Vector3(RW / 2, 0, RD * 0.6))
  const zoomLevel = useStore((s) => s.zoomLevel)

  useFrame(() => {
    if (!avatarRef?.current) return

    const ap = avatarRef.current.position
    smoothTarget.current.x += (ap.x - smoothTarget.current.x) * 0.08
    smoothTarget.current.y += (ap.y + 0.4 - smoothTarget.current.y) * 0.06
    smoothTarget.current.z += (ap.z - smoothTarget.current.z) * 0.08

    const r = zoomLevel
    camera.position.set(
      smoothTarget.current.x + r * Math.sin(CAM_H) * Math.cos(CAM_V),
      smoothTarget.current.y + r * Math.sin(CAM_V),
      smoothTarget.current.z + r * Math.cos(CAM_H) * Math.cos(CAM_V)
    )
    camera.lookAt(smoothTarget.current)

    const asp = camera.right !== undefined
      ? 1
      : window.innerWidth / Math.max(1, window.innerHeight)

    if (camera.isOrthographicCamera) {
      const vs = r * 0.28
      const aspect = window.innerWidth / Math.max(1, window.innerHeight)
      camera.left = -vs * aspect
      camera.right = vs * aspect
      camera.top = vs
      camera.bottom = -vs
      camera.updateProjectionMatrix()
    }
  })

  return null
}

// ── Inner scene (has access to R3F context) ──────────
function SceneInner({ joystickAxis }) {
  const mode        = useStore((s) => s.mode)
  const pendingDef  = useStore((s) => s.pendingDef)
  const items       = useStore((s) => s.items)
  const addItem     = useStore((s) => s.addItem)
  const moveItem    = useStore((s) => s.moveItem)
  const selectedUID = useStore((s) => s.selectedUID)
  const deselect    = useStore((s) => s.deselect)

  const avatarRef = useRef()
  const [ghostPos, setGhostPos] = useState([RW / 2, 0, RD * 0.6])

  function snapToGrid(point, def) {
    if (!def) return [0, 0, 0]
    const gx = Math.floor(point.x / CELL) * CELL
    const gz = Math.floor(point.z / CELL) * CELL
    return [gx, 0, gz]
  }

  const handlePointerMove = useCallback((e) => {
    if (mode === 'place' && pendingDef) {
      setGhostPos(snapToGrid(e.point, pendingDef))
    }
    if (mode === 'drag' && pendingDef) {
      setGhostPos(snapToGrid(e.point, pendingDef))
    }
  }, [mode, pendingDef])

  const handlePointerUp = useCallback((e) => {
    if (mode === 'place' && pendingDef) {
      const snapped = snapToGrid(e.point, pendingDef)
      addItem(pendingDef.id, Math.floor(snapped[0] / CELL), Math.floor(snapped[2] / CELL))
    }
    if (mode === 'drag' && selectedUID && pendingDef) {
      const snapped = snapToGrid(e.point, pendingDef)
      moveItem(selectedUID, Math.floor(snapped[0] / CELL), Math.floor(snapped[2] / CELL))
    }
  }, [mode, pendingDef, selectedUID, addItem, moveItem])

  const handleBackgroundClick = useCallback((e) => {
    if (mode === 'play') deselect()
  }, [mode, deselect])

  return (
    <>
      <CameraController avatarRef={avatarRef} />

      <Room />

      {/* Furniture items */}
      {items.map((item) => (
        <FurnitureInstance key={item.uid} item={item} />
      ))}

      {/* Ghost preview */}
      {(mode === 'place' || mode === 'drag') && pendingDef && (
        <Ghost def={pendingDef} position={ghostPos} />
      )}

      {/* Avatar */}
      <group ref={avatarRef}>
        <Avatar joystickAxis={joystickAxis} avatarGroupRef={avatarRef} />
      </group>

      {/* Pet follows avatar */}
      <Pet avatarRef={avatarRef} />

      {/* Ground raycasting planes */}
      <GroundPlanes
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
      />

      {/* Background click = deselect */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[RW / 2, -0.05, RD / 2]}
        onClick={handleBackgroundClick}
        visible={false}
      >
        <planeGeometry args={[200, 200]} />
        <meshBasicMaterial />
      </mesh>

      {/* Post-processing */}
      <EffectComposer multisampling={0}>
        <SMAA />
        <Bloom
          intensity={0.4}
          luminanceThreshold={0.7}
          luminanceSmoothing={0.3}
          mipmapBlur
        />
        <Vignette eskil={false} offset={0.3} darkness={0.55} />
      </EffectComposer>

      <Preload all />
    </>
  )
}

// ── Main Scene export ────────────────────────────────
export default function Scene({ joystickAxis }) {
  return (
    <Canvas
      shadows
      dpr={[1, Math.min(window.devicePixelRatio, 2)]}
      camera={{ near: 0.1, far: 300 }}
      gl={{
        antialias: false, // SMAA handles it
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.15,
        outputColorSpace: THREE.SRGBColorSpace,
      }}
      style={{ position: 'absolute', inset: 0 }}
    >
      <OrthographicCamera
        makeDefault
        near={0.1}
        far={300}
        position={[RW / 2 + 20, 12, RD / 2 + 20]}
      />
      <SceneInner joystickAxis={joystickAxis} />
    </Canvas>
  )
}
