import { useEffect, useRef } from 'react'

export function useKeyboard() {
  const keys = useRef({ u: false, d: false, l: false, r: false, space: false })

  useEffect(() => {
    const down = (e) => {
      if (e.key === 'ArrowUp'    || e.key === 'w') keys.current.u = true
      if (e.key === 'ArrowDown'  || e.key === 's') keys.current.d = true
      if (e.key === 'ArrowLeft'  || e.key === 'a') keys.current.l = true
      if (e.key === 'ArrowRight' || e.key === 'd') keys.current.r = true
      if (e.key === ' ') keys.current.space = true
    }
    const up = (e) => {
      if (e.key === 'ArrowUp'    || e.key === 'w') keys.current.u = false
      if (e.key === 'ArrowDown'  || e.key === 's') keys.current.d = false
      if (e.key === 'ArrowLeft'  || e.key === 'a') keys.current.l = false
      if (e.key === 'ArrowRight' || e.key === 'd') keys.current.r = false
      if (e.key === ' ') keys.current.space = false
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
    }
  }, [])

  return keys
}
