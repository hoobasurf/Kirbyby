import { useRef, useEffect } from 'react'

export function useJoystick(baseRef, nubRef) {
  const axis = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const base = baseRef.current
    const nub = nubRef.current
    if (!base || !nub) return

    let activeId = -1
    const MAX_R = 28

    function move(cx, cy) {
      const r = base.getBoundingClientRect()
      const dx = cx - (r.left + r.width / 2)
      const dy = cy - (r.top + r.height / 2)
      const dist = Math.sqrt(dx * dx + dy * dy)
      const clamped = Math.min(dist, MAX_R)
      const nx = dist > 0 ? (dx / dist) * clamped : 0
      const ny = dist > 0 ? (dy / dist) * clamped : 0
      nub.style.transform = `translate(calc(-50% + ${nx}px), calc(-50% + ${ny}px))`
      const dead = 4
      axis.current.x = dist > dead ? nx / MAX_R : 0
      axis.current.y = dist > dead ? ny / MAX_R : 0
    }

    function reset() {
      nub.style.transform = 'translate(-50%, -50%)'
      axis.current.x = 0
      axis.current.y = 0
      activeId = -1
    }

    const onTouchStart = (e) => {
      e.preventDefault()
      const t = e.touches[0]
      if (!t) return
      activeId = t.identifier
      move(t.clientX, t.clientY)
    }
    const onTouchMove = (e) => {
      e.preventDefault()
      for (const t of e.changedTouches) {
        if (t.identifier === activeId) { move(t.clientX, t.clientY); break }
      }
    }
    const onTouchEnd = (e) => { e.preventDefault(); reset() }

    base.addEventListener('touchstart', onTouchStart, { passive: false })
    base.addEventListener('touchmove', onTouchMove, { passive: false })
    base.addEventListener('touchend', onTouchEnd, { passive: false })
    base.addEventListener('touchcancel', reset)

    // Mouse fallback
    let mouseDown = false
    const onMouseDown = (e) => { mouseDown = true; move(e.clientX, e.clientY) }
    const onMouseMove = (e) => { if (mouseDown) move(e.clientX, e.clientY) }
    const onMouseUp = () => { if (mouseDown) { mouseDown = false; reset() } }
    base.addEventListener('mousedown', onMouseDown)
    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('mouseup', onMouseUp)

    return () => {
      base.removeEventListener('touchstart', onTouchStart)
      base.removeEventListener('touchmove', onTouchMove)
      base.removeEventListener('touchend', onTouchEnd)
      base.removeEventListener('touchcancel', reset)
      base.removeEventListener('mousedown', onMouseDown)
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('mouseup', onMouseUp)
    }
  }, [])

  return axis
}
