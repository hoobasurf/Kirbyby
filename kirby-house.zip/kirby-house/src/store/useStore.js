import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// ── CATALOGUE ──────────────────────────────────────────
export const CATALOG = [
  // Meubles
  { id: 'bed',       ico: '🛏',  name: 'Lit',          price: 1500, W: 2, D: 2, cat: 'mbl' },
  { id: 'sofa',      ico: '🛋',  name: 'Canapé',       price: 1200, W: 2, D: 1, cat: 'mbl' },
  { id: 'armchair',  ico: '🪑',  name: 'Fauteuil',     price: 800,  W: 1, D: 1, cat: 'mbl' },
  { id: 'dining',    ico: '🍽',  name: 'Table à manger',price: 1400, W: 2, D: 2, cat: 'mbl' },
  { id: 'desk',      ico: '💻',  name: 'Bureau',       price: 900,  W: 2, D: 1, cat: 'mbl' },
  { id: 'wardrobe',  ico: '👚',  name: 'Armoire',      price: 1100, W: 1, D: 1, cat: 'mbl' },
  { id: 'bookshelf', ico: '📚',  name: 'Bibliothèque', price: 700,  W: 1, D: 1, cat: 'mbl' },
  { id: 'tv',        ico: '📺',  name: 'Télévision',   price: 2000, W: 2, D: 1, cat: 'mbl' },
  { id: 'piano',     ico: '🎹',  name: 'Piano',        price: 3500, W: 2, D: 1, cat: 'mbl' },
  { id: 'bar',       ico: '🍹',  name: 'Bar',          price: 2500, W: 2, D: 1, cat: 'mbl' },
  { id: 'rug',       ico: '🟥',  name: 'Tapis',        price: 400,  W: 2, D: 2, cat: 'mbl' },
  { id: 'coffee',    ico: '☕',  name: 'Table basse',  price: 600,  W: 1, D: 1, cat: 'mbl' },
  // Déco
  { id: 'plant',     ico: '🌱',  name: 'Plante',       price: 220,  W: 1, D: 1, cat: 'dec' },
  { id: 'flowers',   ico: '🌸',  name: 'Fleurs',       price: 150,  W: 1, D: 1, cat: 'dec' },
  { id: 'painting',  ico: '🖼',  name: 'Tableau',      price: 500,  W: 1, D: 1, cat: 'dec' },
  { id: 'mirror',    ico: '🪞',  name: 'Miroir',       price: 450,  W: 1, D: 1, cat: 'dec' },
  { id: 'crystal',   ico: '💎',  name: 'Cristal',      price: 600,  W: 1, D: 1, cat: 'dec' },
  { id: 'birdcage',  ico: '🐦',  name: 'Cage à oiseaux',price: 850, W: 1, D: 1, cat: 'dec' },
  { id: 'aquarium',  ico: '🐠',  name: 'Aquarium',     price: 1600, W: 2, D: 1, cat: 'dec' },
  { id: 'globe',     ico: '🌍',  name: 'Globe',        price: 440,  W: 1, D: 1, cat: 'dec' },
  { id: 'clock',     ico: '⏰',  name: 'Horloge',      price: 380,  W: 1, D: 1, cat: 'dec' },
  // Lumière
  { id: 'floorlamp', ico: '💡',  name: 'Lampadaire',   price: 350,  W: 1, D: 1, cat: 'lum' },
  { id: 'tablelamp', ico: '🪔',  name: 'Lampe table',  price: 280,  W: 1, D: 1, cat: 'lum' },
  { id: 'chandelier',ico: '✨',  name: 'Lustre',       price: 3000, W: 2, D: 2, cat: 'lum' },
  { id: 'fireplace', ico: '🔥',  name: 'Cheminée',     price: 2800, W: 2, D: 1, cat: 'lum' },
  { id: 'candles',   ico: '🕯',  name: 'Bougies',      price: 120,  W: 1, D: 1, cat: 'lum' },
  // SdB
  { id: 'bathtub',   ico: '🛁',  name: 'Baignoire',    price: 2200, W: 2, D: 1, cat: 'sdb' },
  { id: 'jacuzzi',   ico: '♨',   name: 'Jacuzzi',      price: 4000, W: 2, D: 2, cat: 'sdb' },
  { id: 'shower',    ico: '🚿',  name: 'Douche',       price: 1800, W: 1, D: 1, cat: 'sdb' },
  { id: 'washbasin', ico: '💧',  name: 'Vasque',       price: 950,  W: 1, D: 1, cat: 'sdb' },
  // Jardin
  { id: 'pool',      ico: '🏊',  name: 'Piscine',      price: 5000, W: 4, D: 3, cat: 'jrd' },
  { id: 'fountain',  ico: '⛲',  name: 'Fontaine',     price: 1800, W: 2, D: 2, cat: 'jrd' },
  { id: 'gazebo',    ico: '🏡',  name: 'Gazebo',       price: 4500, W: 3, D: 3, cat: 'jrd' },
  { id: 'sunbed',    ico: '☀',   name: 'Transat',      price: 350,  W: 2, D: 1, cat: 'jrd' },
]

export const FLOOR_STYLES = [
  { id: 'parquet_dark',  name: 'Parquet brun',   color: '#7a4a28', color2: '#9a6038' },
  { id: 'parquet_honey', name: 'Parquet miel',   color: '#c8822a', color2: '#e8a030' },
  { id: 'marble_white',  name: 'Marbre blanc',   color: '#f0ebe0', color2: '#e0ddd8' },
  { id: 'tile_dark',     name: 'Carrelage noir', color: '#2a2018', color2: '#3a3025' },
  { id: 'tile_pink',     name: 'Carrelage rose', color: '#e8c0b0', color2: '#d09080' },
  { id: 'concrete',      name: 'Béton ciré',     color: '#b0a898', color2: '#a09888' },
  { id: 'herringbone',   name: 'Chevron rouge',  color: '#8b3a2a', color2: '#aa4a38' },
]

export const WALL_COLORS = [
  '#c8a878', '#8b5c1e', '#6b3a2a', '#4a2a8a',
  '#2a5a8a', '#2a7a4a', '#8a7a2a', '#ffffff',
  '#f0e8d8', '#d4c4a8', '#606060', '#1a1008',
]

export const CHARS = [
  { id: 'kirby',   name: 'Kirby',   ico: '🌸' },
  { id: 'waddle',  name: 'Waddle',  ico: '👀' },
  { id: 'meta',    name: 'Meta',    ico: '⚔' },
  { id: 'dedede',  name: 'Dedede',  ico: '👑' },
]

export const PETS = [
  { id: 'cat',   name: 'Chat',  ico: '🐱' },
  { id: 'dog',   name: 'Chien', ico: '🐶' },
  { id: 'bunny', name: 'Lapin', ico: '🐰' },
]

// ── STORE ──────────────────────────────────────────────
let uid = 1

const useStore = create(
  persist(
    (set, get) => ({
      // Room
      floorStyle: 0,
      wallColors: { back: '#c8a878', left: '#b89868', right: '#a88858' },
      items: [],
      coins: 3000,
      gems: 100,

      // Avatar
      charId: 'kirby',
      petId: null,

      // UI state (not persisted)
      mode: 'play',        // play | place | drag
      pendingDef: null,    // item being placed
      selectedUID: null,   // item long-pressed
      panelOpen: true,
      activeTab: 'mbl',
      persoOpen: false,
      zoomLevel: 28,

      // Actions
      setFloor: (i) => set({ floorStyle: i }),
      setWallColor: (side, color) =>
        set((s) => ({ wallColors: { ...s.wallColors, [side]: color } })),

      addItem: (defId, gx, gz) => {
        const def = CATALOG.find((c) => c.id === defId)
        if (!def) return
        const item = { uid: uid++, id: defId, gx, gz, rot: 0 }
        set((s) => ({ items: [...s.items, item], mode: 'play', pendingDef: null }))
      },
      removeItem: (itemUID) =>
        set((s) => ({ items: s.items.filter((x) => x.uid !== itemUID), selectedUID: null })),
      rotateItem: (itemUID) =>
        set((s) => ({
          items: s.items.map((x) =>
            x.uid === itemUID ? { ...x, rot: ((x.rot || 0) + 2) % 16 } : x
          ),
        })),
      moveItem: (itemUID, gx, gz) =>
        set((s) => ({
          items: s.items.map((x) => (x.uid === itemUID ? { ...x, gx, gz } : x)),
          mode: 'play',
          selectedUID: null,
        })),

      startPlace: (def) => set({ mode: 'place', pendingDef: def, selectedUID: null }),
      cancelPlace: () => set({ mode: 'play', pendingDef: null }),
      startDrag: (itemUID) => {
        const item = get().items.find((x) => x.uid === itemUID)
        if (!item) return
        const def = CATALOG.find((c) => c.id === item.id)
        set({ mode: 'drag', selectedUID: itemUID, pendingDef: def })
      },

      selectItem: (uid) => set({ selectedUID: uid }),
      deselect: () => set({ selectedUID: null }),

      setTab: (t) => set({ activeTab: t }),
      togglePanel: () => set((s) => ({ panelOpen: !s.panelOpen })),
      setPersoOpen: (v) => set({ persoOpen: v }),
      setChar: (id) => set({ charId: id }),
      setPet: (id) => set({ petId: id }),
      setZoom: (v) => set({ zoomLevel: Math.max(12, Math.min(52, v)) }),
      resetZoom: () => set({ zoomLevel: 28 }),
    }),
    {
      name: 'kirby-house-v1',
      partialize: (s) => ({
        floorStyle: s.floorStyle,
        wallColors: s.wallColors,
        items: s.items,
        coins: s.coins,
        gems: s.gems,
        charId: s.charId,
        petId: s.petId,
      }),
      onRehydrateStorage: () => (state) => {
        // Fix UIDs after rehydration
        if (state?.items) {
          uid = Math.max(1, ...state.items.map((x) => x.uid + 1))
        }
      },
    }
  )
)

export default useStore
