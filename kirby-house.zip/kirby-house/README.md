# 🏠 Ma Maison Kirby

Un jeu de décoration d'intérieur 3D inspiré de Hotel Hideaway, construit avec **React Three Fiber**, **Zustand** et **Vite**.

## Stack technique

- **React 18** + **Vite 5**
- **Three.js r167** via **@react-three/fiber**
- **@react-three/drei** — helpers (OrthographicCamera, Preload...)
- **@react-three/postprocessing** — Bloom, SMAA, Vignette
- **Zustand** — gestion d'état global avec persistance localStorage
- **Netlify** — déploiement automatique

## Démarrage rapide

```bash
# Installer les dépendances
npm install

# Lancer en développement
npm run dev

# Build production
npm run build

# Prévisualiser le build
npm run preview
```

## Déploiement GitHub + Netlify

1. Push le projet sur GitHub :
```bash
git init
git add .
git commit -m "🏠 Initial commit — Ma Maison Kirby"
git remote add origin https://github.com/TON_COMPTE/kirby-house.git
git push -u origin main
```

2. Sur [netlify.com](https://netlify.com) :
   - **New site from Git** → choisir le repo GitHub
   - Build command : `npm run build`
   - Publish directory : `dist`
   - Cliquer **Deploy site**

Le fichier `netlify.toml` est déjà configuré, rien d'autre à faire.

## Structure du projet

```
src/
├── components/
│   ├── room/
│   │   └── Room.jsx          # Sol, murs, estrade, éclairage
│   ├── furniture/
│   │   ├── Furniture.jsx     # Tous les builders 3D (Bed, Sofa, etc.)
│   │   ├── FurnitureInstance.jsx  # Placement d'un item dans la scène
│   │   └── Ghost.jsx         # Prévisualisation translucide
│   ├── avatar/
│   │   ├── Avatar.jsx        # Kirby + physique + contrôles
│   │   └── Pet.jsx           # Chat, chien, lapin 3D
│   ├── Scene.jsx             # Canvas R3F, caméra, post-processing
│   └── UI.jsx                # Toute l'interface 2D overlay
├── store/
│   └── useStore.js           # Zustand store (état + actions + persistance)
├── hooks/
│   ├── useKeyboard.js        # Clavier WASD/Flèches
│   └── useJoystick.js        # Joystick virtuel touch/mouse
├── data/
│   └── constants.js          # Dimensions de la pièce, constantes caméra
├── App.jsx
└── main.jsx
```

## Features

- 🎮 Déplacement avatar (WASD / joystick tactile / saut)
- 🛋 44 meubles et décorations à placer style Hotel Hideaway
- 🪟 7 styles de sol avec texture chevron procédurale
- 🧱 Couleurs de murs personnalisables (par côté)
- 📸 Caméra isométrique avec zoom +/- et reset
- 🐾 3 animaux 3D réalistes (chat, chien, lapin)
- 🌸 4 personnages (Kirby, Waddle Dee, Meta Knight, Dedede)
- ✨ Post-processing : Bloom + SMAA + Vignette
- 💾 Sauvegarde automatique (Zustand persist + localStorage)
